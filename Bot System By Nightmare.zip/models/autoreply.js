const { Schema, model } = require("mongoose");
const auto = new  Schema({
  id: { type: String},
  word : {type : String},
  reply : {type : String},
 
});

module.exports = model("auto" , auto)