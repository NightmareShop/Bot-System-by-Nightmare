const { Schema, model } = require("mongoose");

const felll = new Schema (
  {
    id: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      required: true,
    },
 
 

  }
)
module.exports = model ('felll' , felll)