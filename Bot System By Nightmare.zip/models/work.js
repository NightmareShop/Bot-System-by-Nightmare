const {model , Schema} = require ("mongoose")

const seso = new Schema(
    {
        id : String , 
        wallet : {type : Number , default : 0} , 
        bank : {type : Number , default : 0} , 
        cooldowns : {
            work : {type : Date}
        }
    }
)

module.exports = model("seso", seso)