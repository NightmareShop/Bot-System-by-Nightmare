module.exports = async (clientr) => {
  let array = [

    {
      name: "new-devbadge",
      description: "get new developer badge",
      
    },

 
  ];
  await clientr.application.commands.set(array);
}