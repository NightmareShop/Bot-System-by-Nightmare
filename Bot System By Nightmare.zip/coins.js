module.exports = async (clientr) => {
    let array =  [
        {
          name: "say",
          description: "Say anything",
          options: [
            {
              name: "with-embed",
              description: "Say with an embed",
              type: "SUB_COMMAND",
              options: [
                {
                  name: "description",
                  description: "The description of the embed",
                  type: "STRING",
                  required: true
                },
                {
                  name: "image",
                  description: "The image URL of the embed",
                  type: "STRING",
                  required:true
                },
                {
                  name: "color",
                  description: "The color of the embed",
                  type: "STRING",
                  required: true
                }
              ]
            },
            {
              name: "without-embed",
              description: "Say without an embed",
              type: "SUB_COMMAND",
              options: [
                {
                  name: "message",
                  description: "The message to say",
                  type: "STRING",
                  required: true
                }
              ]
            }
          ]
        } , 
   

{
    name: "embed",
    description: "put your channels to verify line in it",
    options: [

          {
            name: "role",
            description: "put your youtube image channel",
            type: "ROLE" ,
            required : true
          } ,
          {
            name: "channel",
            description: "put your youtube image channel",
            type: "CHANNEL" ,
            required : true
          } ,
          {
            name: "title",
            description: "put your youtube image channel",
            type: "STRING" ,
            required : true
          } ,
          {
            name: "description",
            description: "put your youtube image channel",
            type: "STRING" ,
            required : true
          } ,
          {
            name: "glitch",
            description: "put ",
            type: "STRING" ,
            required : true
          } ,
          {
            name: "github",
            description: "put ",
            type: "STRING" ,
            required : true
          } ,
          {
            name: "video",
            description: "put ",
            type: "STRING" ,
            required : true
          } ,
          {
            name: "image",
            description: "put ",
            type: "STRING" ,
            required : true
          } ,

        ]
      },

      {
        name: "autoreply",
        description: "رد تلقائى",
        options: [
          {
            name: "word",
            description: "ضع الكلمة التى تريد الرد عليها",
            type: "STRING",
            required: true
          },
          {
            name: "reply",
            description: "ضع الرد على هذه الكلمة",
            type: 'STRING',
            required: true
          },
  
        ]
      },
  
   {
        name: "delete-word",
        description: "لحذف كلمة معينة من وحدة التخزيين",
        options: [
          {
            name: "word",
            description: "ضع الكلمة التى تريد حذفها",
            type: "STRING",
            required: true
          },
  
        ]
      },




      ];
      
    await clientr.application.commands.set(array);
  }