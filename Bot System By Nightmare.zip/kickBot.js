const Discord = require('discord.js')

const fs = require('fs');

const { MessageAttachment } = require('discord.js');
const { MessageEmbed , permissionOverwrites , ChannelType ,WebhookClient , MessageButton , Modal  , MessageSelectMenu , MessageActionRow , TextInputComponent, Permissions} = require("discord.js");
const { Client, Intents } = require('discord.js');


const mongoose = require("mongoose");
const token = require('./models/tokennts.js');
const linee = require ('./models/line.js');


function createKickBot(token) {
    const client = new Client({ intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"] });
  
    client.on('ready', () => {
      console.log(`Kick bot is online with token ${token}`);
    });
        mongoose.connect(""); //////// ؤابط المونجو
client.on("ready", async () => {
 const coi = require('./coins.js')
 await coi(client)
    client.user.setActivity(`Finx`, {
    type: "PLAYING"
  });
    console.log(client.user.tag);
   
  });
      

//// put your bot code here
const ms = require('ms')
const svgCaptcha = require('svg-captcha');
const canvas = require('canvas')


////////////

let optionss = [{
    label: "Support",
    description: " تكت الدعم الفنى",
    value: 'levell',
    emoji : `1177798978352455791` , 
 
  
    selected: false
  },


  {
    label: "Report",
    description: "بلاغ",
    value: 'le1',
    emoji : `1176478905562050611` , 
 
  
    selected: false
  },



  {
    label: "Compensation",
    description: "التعويض",
    value: 'le2',
    emoji : `1213129684309639208` , 
 
  
    selected: false
  },
  
  
  
  {
    label: 'Reset',
    description: 'Reset the selected option',
    value: 'reset',
     emoji : `↩️`,
    selected: false
  }
  
  
  ];
  
  // Shorten the value of each option to 100 characters or less
  optionss.forEach(option => {
  option.value = option.value.slice(0, 100);
  });
  
  
  
  client.on('messageCreate', async (message) => {
    if (message.content.startsWith('tic')) {
    if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
        return message.reply({
          content: 'You do not have permission to use this command!',
         
        });
      }
      const ment = new MessageSelectMenu()
      .setCustomId('hope5')
      .setPlaceholder('nothing selected')
      .setMaxValues(1)
      .setMinValues(1)
      .addOptions(optionss)
//   const btnn = new MessageButton()
//   .setLabel('فيديو الشرح')
//   .setEmoji('1106135549011558430')
//   .setStyle('LINK')
//   .setURL('https://youtu.be/IYEzK55iZ9E')
//    const roww = new MessageActionRow()
//       .addComponents(btnn)
    const row = new MessageActionRow()
      .addComponents(ment)
  
        message.channel.send({
        embeds: [new MessageEmbed().setDescription(`**FinxMC Ticket
        # FinxMC- Support الدعم الفني
        مشكله عامه
        طلب فك الباند
        مشكله في الشوب او الرتب
        
        # :FinxMc: - compensation تعويض
        تم قتلك بسبب تعليق بالسيرفر
        تم قتلك بواسطه شخص يستخدم الغش او الهاك
        
        # :FinxMc: - Report بلاغ
        بلاغ على اداري
        بلاغ على لاعب
        
        "ملاحظه"
        
        سيتم اغلاق التذكره في حال مرور ١٠ دقائق من فتحك ل التكت دون كتابه السبب
        
        سيتم اغلاق التكت في اي وقت نعتقد اننا حللنا مشكلتك
        
        في حال انك فتحت تذكره ل الاستهبال او لأي اسباب ممكن يعطلنا بدون فايده سيتم حظرك من فتح التذاكر 
        **`).setThumbnail(message.guild.iconURL({dynamic : true})).setFooter({text : `FinxMC Ticket` , value : `${message.guild.name}`})],
        components: [row ]
      });
    }
  });
  
  
  
  
  const counter = require('./models/counter.js');
  client.on('interactionCreate', async (interaction) => {
    
    if (!interaction.isSelectMenu()) return
  
      if (interaction.customId === `hope5`) {
  
  
        
          let selectedOption = interaction.values[0];
          
            
          
        
      
         if (selectedOption === 'levell') {
                       
  
             try {
             
        
              const modal = new Modal()
              .setCustomId('myModal')
              .setTitle('My Modal');
        
            const tokennnn = new TextInputComponent()
              .setCustomId('mc')
              .setLabel("ضع اسمك فى ماين كرافت")
              .setStyle('SHORT');
        
            
              
            const time = new TextInputComponent()
              .setCustomId('reason')
              .setLabel("سبب التكت")
              .setStyle('SHORT');
         
        
        
              
        
            const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
         
            const thirdActionRowwww = new MessageActionRow().addComponents(time);
        
          
            modal.addComponents(firstActionRowwww, thirdActionRowwww );
        
            await interaction.showModal(modal);

           
            } catch (error) {
              console.error(error);
                     const errorMessage = `An error occurred: ${error.message}`;
        
          // Send the error message to the webhook
          await axios.post(webhookClient.url, { content: errorMessage });
              interaction.reply({content : '**ربما انت لم تحدد ايدى الكاتوجرى بشكل صحيح او ربما انت تستخدم بوت حماية او مفعل التو فاكتور فى سيرفرك \n لكى يستطيع البوت بفتح تكت انت يجب ان تغلق بوت الحماية او تغلق التو فاكتور او تعطر البوت الميكر رتبة اعلى من رتبة بوت الحماية ** ' , ephemeral : true});
            }
         
          }
        
        



          //

          if (selectedOption === 'le1') {
                       
  
            try {
            
       
             const modal = new Modal()
             .setCustomId('myModal1')
             .setTitle('My Modal');
       
           const tokennnn = new TextInputComponent()
             .setCustomId('mc1')
             .setLabel("MC")
             .setStyle('SHORT');
       
           
             
           const time = new TextInputComponent()
             .setCustomId('mc2')
             .setLabel("الادارى MC")
             .setStyle('SHORT');
        
             const time1 = new TextInputComponent()
             .setCustomId('mc3')
             .setLabel("سبب التبليغ")
             .setStyle('SHORT');
        
       
             
       
           const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
        
           const thirdActionRowwww = new MessageActionRow().addComponents(time);
           const thirdActionRowwww1 = new MessageActionRow().addComponents(time1);
       
         
           modal.addComponents(firstActionRowwww, thirdActionRowwww , thirdActionRowwww1);
       
           await interaction.showModal(modal);

          
           } catch (error) {
             console.error(error);
                    const errorMessage = `An error occurred: ${error.message}`;
       
         // Send the error message to the webhook
         await axios.post(webhookClient.url, { content: errorMessage });
             interaction.reply({content : '**ربما انت لم تحدد ايدى الكاتوجرى بشكل صحيح او ربما انت تستخدم بوت حماية او مفعل التو فاكتور فى سيرفرك \n لكى يستطيع البوت بفتح تكت انت يجب ان تغلق بوت الحماية او تغلق التو فاكتور او تعطر البوت الميكر رتبة اعلى من رتبة بوت الحماية ** ' , ephemeral : true});
           }
        
         }
  
          ////
         

          if (selectedOption === 'le2') {
                       
  
            try {
            
       
             const modal = new Modal()
             .setCustomId('myModal2')
             .setTitle('My Modal');
       
           const tokennnn = new TextInputComponent()
             .setCustomId('mc4')
             .setLabel("MC")
             .setStyle('SHORT');
       
           
             
           const time = new TextInputComponent()
             .setCustomId('mc5')
             .setLabel("سبب التعويض")
             .setStyle('SHORT');
        
             const time1 = new TextInputComponent()
             .setCustomId('mc6')
             .setLabel("دليلك")
             .setStyle('SHORT');
        
       
             
       
           const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
        
           const thirdActionRowwww = new MessageActionRow().addComponents(time);
           const thirdActionRowwww1 = new MessageActionRow().addComponents(time1);
       
         
           modal.addComponents(firstActionRowwww, thirdActionRowwww , thirdActionRowwww1);
       
           await interaction.showModal(modal);

          
           } catch (error) {
             console.error(error);
                    const errorMessage = `An error occurred: ${error.message}`;
       
         // Send the error message to the webhook
         await axios.post(webhookClient.url, { content: errorMessage });
             interaction.reply({content : '**ربما انت لم تحدد ايدى الكاتوجرى بشكل صحيح او ربما انت تستخدم بوت حماية او مفعل التو فاكتور فى سيرفرك \n لكى يستطيع البوت بفتح تكت انت يجب ان تغلق بوت الحماية او تغلق التو فاكتور او تعطر البوت الميكر رتبة اعلى من رتبة بوت الحماية ** ' , ephemeral : true});
           }
        
         }
  
          //
  
  
          if (selectedOption === 'reset') {

            await interaction.reply({content : `Done reset the ticket`  , ephemeral : true})
  
          }
  
        
  }
  })

  client.on('interactionCreate', async (interaction) => {
    if (!interaction.isModalSubmit()) return;
  
    if (interaction.customId === 'myModal') {
  
      
        const tokennn = interaction.fields.getTextInputValue('mc');
       
        const time = interaction.fields.getTextInputValue('reason');

        const guildId = interaction.guild.id;
  
   
        const ticketNumber = (
          await counter.findOneAndUpdate(
            { id: interaction.guild.id },
            { $inc: { count: 1 } },
            { upsert: true, new: true }
          )
        ).count;
        const category = `1212447531338956801`;
  
        const channelName = `ticket-${ticketNumber}`;
  
        const channel = await interaction.guild.channels.create(channelName, {
          type: 'GUILD_TEXT',
          parent: category,
          permissionOverwrites: [
            {
              id: interaction.guild.id,
              deny: ['VIEW_CHANNEL'],
            },
            {
              id: interaction.user.id,
              allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
            },
          ],
        });

        const role = `1213082605042532392`
        const rr = interaction.guild.roles.cache.get(role)
          const close = new MessageButton()
            .setCustomId('closeart')
            .setLabel('close')
            .setStyle('DANGER')
            .setEmoji('🔒')
    
      
    
          const uud = new MessageActionRow().addComponents( close);
    
            channel.send({
            content: `<@${interaction.user.id}> ${rr} `,
            embeds: [
              new MessageEmbed().setDescription(
                `** وف يتم الرد عليك من فريق الدعم الرجاء ارسل دليلك او مشكلتك والاتنظار
                لي اغلق التذكرة اضغط 🔒
                
                staff team will respond as soon as possible please send your problem and wait
                to close the ticket press 🔒
**`
              ),
            ],
        
          });
          
          channel.send({
         
            embeds: [
              new MessageEmbed().addFields({name : `MC` , value : `${tokennn}`}).addFields({name : `سبب التكت` , value : `${time}`})
            ],
            components: [uud],
          });
          

   
          await interaction.reply({
            content: `*✔ Ticket Created <#${channel.id}>*`,
            ephemeral: true,
          });
        
  
        // Send the error message to the webhook
       
       
      
    }
  });





//
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModal1') {

    
      const tokennn = interaction.fields.getTextInputValue('mc1');
     
      const time = interaction.fields.getTextInputValue('mc2');
      const time1 = interaction.fields.getTextInputValue('mc3');

      const guildId = interaction.guild.id;

 
      const ticketNumber = (
        await counter.findOneAndUpdate(
          { id: interaction.guild.id },
          { $inc: { count: 1 } },
          { upsert: true, new: true }
        )
      ).count;
      const category = `1212447531338956801`;

      const channelName = `ticket-${ticketNumber}`;

      const channel = await interaction.guild.channels.create(channelName, {
        type: 'GUILD_TEXT',
        parent: category,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['VIEW_CHANNEL'],
          },
          {
            id: interaction.user.id,
            allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
          },
        ],
      });

      const role = `1213082605042532392`
      const rr = interaction.guild.roles.cache.get(role)
        const close = new MessageButton()
          .setCustomId('closeart')
          .setLabel('close')
          .setStyle('DANGER')
          .setEmoji('🔒')
  
    
  
        const uud = new MessageActionRow().addComponents( close);
  
          channel.send({
          content: `<@${interaction.user.id}> ${rr} `,
          embeds: [
            new MessageEmbed().setDescription(
              `** وف يتم الرد عليك من فريق الدعم الرجاء ارسل دليلك او مشكلتك والاتنظار
              لي اغلق التذكرة اضغط 🔒
              
              staff team will respond as soon as possible please send your problem and wait
              to close the ticket press 🔒
**`
            ),
          ],
      
        });
        
        channel.send({
       
          embeds: [
            new MessageEmbed().addFields({name : `MC` , value : `${tokennn}`}).addFields({name : "الادارى MC" , value : `${time}`}).addFields({name : "سبب التبليغ" , value : `${time1}`})
          ],
          components: [uud],
        });
        

 
        await interaction.reply({
          content: `*✔ Ticket Created <#${channel.id}>*`,
          ephemeral: true,
        });
      

      // Send the error message to the webhook
     
     
    
  }
});




client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModal2') {

    
      const tokennn = interaction.fields.getTextInputValue('mc4');
     
      const time = interaction.fields.getTextInputValue('mc5');
      const time1 = interaction.fields.getTextInputValue('mc6');

      const guildId = interaction.guild.id;

 
      const ticketNumber = (
        await counter.findOneAndUpdate(
          { id: interaction.guild.id },
          { $inc: { count: 1 } },
          { upsert: true, new: true }
        )
      ).count;
      const category = `1212447531338956801`;

      const channelName = `ticket-${ticketNumber}`;

      const channel = await interaction.guild.channels.create(channelName, {
        type: 'GUILD_TEXT',
        parent: category,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['VIEW_CHANNEL'],
          },
          {
            id: interaction.user.id,
            allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
          },
        ],
      });

      const role = `1213082605042532392`
      const rr = interaction.guild.roles.cache.get(role)
        const close = new MessageButton()
          .setCustomId('closeart')
          .setLabel('close')
          .setStyle('DANGER')
          .setEmoji('🔒')
  
    
  
        const uud = new MessageActionRow().addComponents( close);
  
          channel.send({
          content: `<@${interaction.user.id}> ${rr} `,
          embeds: [
            new MessageEmbed().setDescription(
              `** وف يتم الرد عليك من فريق الدعم الرجاء ارسل دليلك او مشكلتك والاتنظار
              لي اغلق التذكرة اضغط 🔒
              
              staff team will respond as soon as possible please send your problem and wait
              to close the ticket press 🔒
**`
            ),
          ],
      
        });
        
        channel.send({
       
          embeds: [
            new MessageEmbed().addFields({name : `MC` , value : `${tokennn}`}).addFields({name : "سبب التعويض" , value : `${time}`}).addFields({name : "دليلك" , value : `${time1}`})
          ],
          components: [uud],
        });
        

 
        await interaction.reply({
          content: `*✔ Ticket Created <#${channel.id}>*`,
          ephemeral: true,
        });
      

      // Send the error message to the webhook
     
     
    
  }
});




  const Points = require('./models/points.js');

  client.on('interactionCreate', async (interaction) => {
    if (interaction.isButton()) {
      if (interaction.customId === 'closeart') {
        // Check if the user has the specific role
        if (interaction.member.roles.cache.some(role => role.id === '1213082605042532392')) {
     
          const user = interaction.user
          // Award points to the user
          const userId = interaction.user.id;
          try {
            let userPoints = await Points.findOne({ userId });
            if (!userPoints) {
              userPoints = await Points.create({ userId });
            }
            userPoints.points += 1;
            await userPoints.save();
            setTimeout( async () => {
                await interaction.channel.delete();  
            }, 5000);
            interaction.reply('Ticket will closed. and You earned 1 point!');
          } catch (error) {
            console.error(error);
            interaction.reply('An error occurred while awarding points.');
          }
        } else {
          interaction.reply('You do not have permission to close this ticket.');
        }
      }
    }
  });




  
    // Check if the author is a member of the specific role
  // Map to store word counts for each user

  const messageCounts = new Map();

  client.on('messageCreate', async (message) => {
    if (message.member.roles.cache.some(role => role.id === '1213082605042532392')) {
      const userId = message.author.id;
  
      // Update the cumulative message count for the user
      if (!messageCounts.has(userId)) {
        messageCounts.set(userId, 1); // Start with 1 to count the current message
      } else {
        messageCounts.set(userId, messageCounts.get(userId) + 1); // Increment the message count
      }
  
      // Calculate points based on cumulative message count
      let pointsEarned = 0;
      const cumulativeMessages = messageCounts.get(userId);
  
      if (cumulativeMessages >= 1000) { //// 1000
        pointsEarned = 5;
      } else if (cumulativeMessages >= 500) {
        pointsEarned = 3;
      }
  
      if (pointsEarned > 0) {
        try {
          let userPoints = await Points.findOne({ userId });
          if (!userPoints) {
            userPoints = await Points.create({ userId });
          }
          userPoints.points += pointsEarned;
          await userPoints.save();
          await message.channel.send({ content: `<@${userId}> you earned ${pointsEarned} points.` });
        } catch (error) {
          console.error(error);
        }
      }
    }
  });








  client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;
  
    const { commandName, options } = interaction;
  
    if (commandName === 'points') {
        let user = interaction.user;
  
        // Check if the command has a user option provided
        const specifiedUser = options.getUser('user');
        if (specifiedUser) {
            // If a user is specified, use that user instead
            user = specifiedUser;
        }
  
        // Retrieve user's wallet balance from the database
        const userData = await Points.findOne({ userId: user.id });
  
        if (!userData) {
            return interaction.reply({ content: 'This user doesn\'t have points yet.' });
        }
  
        const walletBalance = userData.points;
  
        // Send the user's wallet balance as a message
        await interaction.reply({ embeds: [new MessageEmbed().addFields({name : `Your points` , value : ` \`\ ${walletBalance} \`\ points.`}).setThumbnail(user.displayAvatarURL({dynamic : true})).setTimestamp().setTitle(user.username)]});
    }
  });







client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;



  if (interaction.commandName === 'close') {

    if (interaction.member.roles.cache.some(role => role.id === '1213082605042532392')) {
     
      const user = interaction.user
      // Award points to the user
      const userId = interaction.user.id;
      try {
        let userPoints = await Points.findOne({ userId });
        if (!userPoints) {
          userPoints = await Points.create({ userId });
        }
        userPoints.points += 1;
        await userPoints.save();
        setTimeout( async () => {
            await interaction.channel.delete();  
        }, 5000);
        interaction.reply('Ticket will closed. and You earned 1 point!');
      } catch (error) {
        console.error(error);
        interaction.reply('An error occurred while awarding points.');
      }
    } else {
      interaction.reply('You do not have permission to close this ticket.');
    }

  }
})



























client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const { commandName, options } = interaction;

  if (commandName === 'top') {
      try {
          const users = await Points.find();

          const sortUsers = users.sort((a, b) => {
              return b.points - a.points;
          }).slice(0, 20);

          await interaction.deferReply({ fetchReply: true });
          await interaction.editReply({
              embeds: [
                  new MessageEmbed()
                      .setAuthor(`${interaction.guild.name} Ticket top`)
                      .setColor("RANDOM")
                      .setTitle("The top 20 of Point")
                      .setDescription(sortUsers.map((user, index) => {
                          return `**\`[${index + 1}]\`** : **<@${user.userId}>** : \`${user.points} points\``
                      }).join("\n"))
              ]
          });
      } catch (err) {
          console.error('Error occurred:', err);
          await interaction.reply({ content: 'An error occurred while fetching top users. Please try again later.' });
      }
  }
});
  client.login(token);

  return client;
}

module.exports = createKickBot;