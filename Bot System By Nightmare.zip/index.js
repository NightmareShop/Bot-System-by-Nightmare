const config = require("./config.json");
const prefix = config.prefix;
const Discord = require("discord.js");
const fs = require('fs');
const createKickBot = require('./kickBot.js');
const createbanBot = require('./banBot.js');

const { MessageAttachment } = require('discord.js');
const { MessageEmbed, permissionOverwrites, ChannelType, Permissions , MessageSelectMenu , Modal ,  TextInputComponent, MessageButton , MessageActionRow } = require("discord.js");
const { Client, Intents } = require('discord.js');
const client = new Discord.Client({
  intents: ["GUILDS", "GUILD_MESSAGES", "GUILD_MEMBERS" , "GUILD_PRESENCES" , "GUILD_BANS" , "GUILD_INVITES" , "GUILD_MESSAGE_REACTIONS" , "GUILD_MESSAGE_TYPING" , "DIRECT_MESSAGES" , "DIRECT_MESSAGE_REACTIONS" , "DIRECT_MESSAGE_TYPING"]
});

// Require the ban bot module and pass the Client class
// const banBot = require('./banBot')(Client, ''); ////////// https://youtu.be/gtykpkOYy94

client.on('ready', async () => {


  console.log('Bot is online!');
});
const mongoose = require("mongoose");
const db = require("./models/shop");
const user_db = require("./models/user");
const toto = require("./models/steck");
const tokens = require("./models/tokens");

const axios = require("axios");
const i18n = require('i18n');

i18n.configure({
  locales: ['en', 'ar'],
  directory: __dirname + '/locales',
  defaultLocale: 'en',
  objectNotation: true
});


mongoose.connect("mongodb+srv://Nightmare:vfPa3QRKmOsuBs3y@nightmare.hk9jjye.mongodb.net/data"); //////// ؤابط المونجو


console.log('Connected to MongoDB');
client.on("ready", async () => {
  console.log(client.user.tag);
  
  
});

process.on("unhandledRejection", error => {
  return;
});
process.on("unhandledRejection", error => {
  return;
});
process.on("unhandledRejection", error => {
  return;
});

process.on("unhandledRejection", error => {
  return console.log(error)
});

const uad = require('./coins.js')


client.on('ready', async () => {
  await uad(client)
  function abady() {
    let status = [`system200`]
    let S = Math.floor(Math.random() * status.length);
    client.user.setActivity(status[S], { type: 'PLAYING' })

 
  };
  //ismailmgde
  setInterval(abady, 5000)

})



///////////////////////////// https://youtu.be/gtykpkOYy94   
///



                                                 ///////////////////////////////////////////////////////////////////
                                                 ///                         تكت                                ///
                                                ///////////////////////////////////////////////////////////////////

let optionss = [{
  label: "Support | الدعم الفنى",
  description: " تكت الدعم الفنى",
  value: 'levell',
  emoji : `1177798978352455791` , 


  selected: false
},


{
  label: "Report | ابلاغ",
  description: "بلاغ",
  value: 'le1',
  emoji : `1176478905562050611` , 


  selected: false
},



{
  label: "تقديم على السبورت | Apply Team",
  description: "تقديم على السبورت",
  value: 'le2',
  emoji : `1213129684309639208` , 


  selected: false
},



{
  label: 'Reset',
  description: 'Reset the selected option',
  value: 'reset',
   emoji : `↩️`,
  selected: false
}


];

// Shorten the value of each option to 100 characters or less
optionss.forEach(option => {
option.value = option.value.slice(0, 100);
});



client.on('messageCreate', async (message) => {
  if (message.content.startsWith('tic')) {
  if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
      return message.reply({
        content: 'You do not have permission to use this command!',
       
      });
    }
    const ment = new MessageSelectMenu()
    .setCustomId('hope5')
    .setPlaceholder('nothing selected')
    .setMaxValues(1)
    .setMinValues(1)
    .addOptions(optionss)

  const row = new MessageActionRow()
    .addComponents(ment)

      message.channel.send({
      embeds: [new MessageEmbed().setDescription(`**
      #  Support الدعم الفني
      مشكله عامه
      طلب فك الباند
      مشكله في الشوب او الرتب
      

      
      # :: - Report بلاغ
      بلاغ على اداري
      


      # :: - تقديم على الادارة

      
      "ملاحظه"
      
      سيتم اغلاق التذكره في حال مرور ١٠ دقائق من فتحك ل التكت دون كتابه السبب
      
      سيتم اغلاق التكت في اي وقت نعتقد اننا حللنا مشكلتك
      
      في حال انك فتحت تذكره ل الاستهبال او لأي اسباب ممكن يعطلنا بدون فايده سيتم حظرك من فتح التذاكر 
      **`).setThumbnail(message.guild.iconURL({dynamic : true})).setFooter({text : `Ticket` , value : `${message.guild.name}`})],
      components: [row ]
    });
  }
});




const counter = require('./models/counter.js');
client.on('interactionCreate', async (interaction) => {
  
  if (!interaction.isSelectMenu()) return

    if (interaction.customId === `hope5`) {


      
        let selectedOption = interaction.values[0];
        
          
        
      
    
       if (selectedOption === 'levell') {
                     

           try {
           
      
            const modal = new Modal()
            .setCustomId('myModal')
            .setTitle('My Modal');
      
          const tokennnn = new TextInputComponent()
            .setCustomId('mc')
            .setLabel("ضع اسمك ")
            .setStyle('SHORT');
      
          
            
          const time = new TextInputComponent()
            .setCustomId('reason')
            .setLabel("سبب التكت")
            .setStyle('SHORT');
       
      
      
            
      
          const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
       
          const thirdActionRowwww = new MessageActionRow().addComponents(time);
      
        
          modal.addComponents(firstActionRowwww, thirdActionRowwww );
      
          await interaction.showModal(modal);

         
          } catch (error) {
            console.error(error);
                
            interaction.reply({content : '**ربما انت لم تحدد ايدى الكاتوجرى بشكل صحيح او ربما انت تستخدم بوت حماية او مفعل التو فاكتور فى سيرفرك \n لكى يستطيع البوت بفتح تكت انت يجب ان تغلق بوت الحماية او تغلق التو فاكتور او تعطر البوت الميكر رتبة اعلى من رتبة بوت الحماية ** ' , ephemeral : true});
          }
       
        }
      
      



        //

        if (selectedOption === 'le1') {
                     

          try {
          
     
           const modal = new Modal()
           .setCustomId('myModal1')
           .setTitle('My Modal');
     
         const tokennnn = new TextInputComponent()
           .setCustomId('mc1')
           .setLabel("MC")
           .setStyle('SHORT');
     
         
           
         const time = new TextInputComponent()
           .setCustomId('mc2')
           .setLabel("الادارى MC")
           .setStyle('SHORT');
      
           const time1 = new TextInputComponent()
           .setCustomId('mc3')
           .setLabel("سبب التبليغ")
           .setStyle('SHORT');
      
     
           
     
         const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
      
         const thirdActionRowwww = new MessageActionRow().addComponents(time);
         const thirdActionRowwww1 = new MessageActionRow().addComponents(time1);
     
       
         modal.addComponents(firstActionRowwww, thirdActionRowwww , thirdActionRowwww1);
     
         await interaction.showModal(modal);

        
         } catch (error) {
           console.error(error);
   
           interaction.reply({content : '**ربما انت لم تحدد ايدى الكاتوجرى بشكل صحيح او ربما انت تستخدم بوت حماية او مفعل التو فاكتور فى سيرفرك \n لكى يستطيع البوت بفتح تكت انت يجب ان تغلق بوت الحماية او تغلق التو فاكتور او تعطر البوت الميكر رتبة اعلى من رتبة بوت الحماية ** ' , ephemeral : true});
         }
      
       }

        ////
       

        if (selectedOption === 'le2') {
                     

          try {
          
     
           const modal = new Modal()
           .setCustomId('myModal2')
           .setTitle('My Modal');
     
         const tokennnn = new TextInputComponent()
           .setCustomId('mc4')
           .setLabel("MC")
           .setStyle('SHORT');
     
         
           
         const time = new TextInputComponent()
           .setCustomId('mc5')
           .setLabel("سبب التعويض")
           .setStyle('SHORT');
      
           const time1 = new TextInputComponent()
           .setCustomId('mc6')
           .setLabel("دليلك")
           .setStyle('SHORT');
      
     
           
     
         const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
      
         const thirdActionRowwww = new MessageActionRow().addComponents(time);
         const thirdActionRowwww1 = new MessageActionRow().addComponents(time1);
     
       
         modal.addComponents(firstActionRowwww, thirdActionRowwww , thirdActionRowwww1);
     
         await interaction.showModal(modal);

        
         } catch (error) {
           console.error(error);
     
           interaction.reply({content : '**ربما انت لم تحدد ايدى الكاتوجرى بشكل صحيح او ربما انت تستخدم بوت حماية او مفعل التو فاكتور فى سيرفرك \n لكى يستطيع البوت بفتح تكت انت يجب ان تغلق بوت الحماية او تغلق التو فاكتور او تعطر البوت الميكر رتبة اعلى من رتبة بوت الحماية ** ' , ephemeral : true});
         }
      
       }

        //


        if (selectedOption === 'reset') {

          await interaction.reply({content : `Done reset the ticket`  , ephemeral : true})

        }

      
}
})

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModal') {

    
      const tokennn = interaction.fields.getTextInputValue('mc');
     
      const time = interaction.fields.getTextInputValue('reason');

      const guildId = interaction.guild.id;

 
      const ticketNumber = (
        await counter.findOneAndUpdate(
          { id: interaction.guild.id },
          { $inc: { count: 1 } },
          { upsert: true, new: true }
        )
      ).count;
      const category = `1226947005411229800`;

      const channelName = `ticket-${ticketNumber}`;

      const channel = await interaction.guild.channels.create(channelName, {
        type: 'GUILD_TEXT',
        parent: category,
        permissionOverwrites: [
          {
            id: interaction.guild.id,
            deny: ['VIEW_CHANNEL'],
          },
          {
            id: interaction.user.id,
            allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
          },
        ],
      });

      const role = `1213082605042532392`
      const rr = interaction.guild.roles.cache.get(role)
        const close = new MessageButton()
          .setCustomId('closeart')
          .setLabel('close')
          .setStyle('DANGER')
          .setEmoji('🔒')
  
    
  
        const uud = new MessageActionRow().addComponents( close);
  
          channel.send({
          content: `<@${interaction.user.id}> ${rr} `,
          embeds: [
            new MessageEmbed().setDescription(
              `** وف يتم الرد عليك من فريق الدعم الرجاء ارسل دليلك او مشكلتك والاتنظار
              لي اغلق التذكرة اضغط 🔒
              
              staff team will respond as soon as possible please send your problem and wait
              to close the ticket press 🔒
**`
            ),
          ],
      
        });
        
        channel.send({
       
          embeds: [
            new MessageEmbed().addFields({name : `MC` , value : `${tokennn}`}).addFields({name : `سبب التكت` , value : `${time}`})
          ],
          components: [uud],
        });
        

 
        await interaction.reply({
          content: `*✔ Ticket Created <#${channel.id}>*`,
          ephemeral: true,
        });
      

      // Send the error message to the webhook
     
     
    
  }
});





//
client.on('interactionCreate', async (interaction) => {
if (!interaction.isModalSubmit()) return;

if (interaction.customId === 'myModal1') {

  
    const tokennn = interaction.fields.getTextInputValue('mc1');
   
    const time = interaction.fields.getTextInputValue('mc2');
    const time1 = interaction.fields.getTextInputValue('mc3');

    const guildId = interaction.guild.id;


    const ticketNumber = (
      await counter.findOneAndUpdate(
        { id: interaction.guild.id },
        { $inc: { count: 1 } },
        { upsert: true, new: true }
      )
    ).count;
    const category = `1212447531338956801`;

    const channelName = `ticket-${ticketNumber}`;

    const channel = await interaction.guild.channels.create(channelName, {
      type: 'GUILD_TEXT',
      parent: category,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: ['VIEW_CHANNEL'],
        },
        {
          id: interaction.user.id,
          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
        },
      ],
    });

    const role = `1213082605042532392`
    const rr = interaction.guild.roles.cache.get(role)
      const close = new MessageButton()
        .setCustomId('closeart')
        .setLabel('close')
        .setStyle('DANGER')
        .setEmoji('🔒')

  

      const uud = new MessageActionRow().addComponents( close);

        channel.send({
        content: `<@${interaction.user.id}> ${rr} `,
        embeds: [
          new MessageEmbed().setDescription(
            `** وف يتم الرد عليك من فريق الدعم الرجاء ارسل دليلك او مشكلتك والاتنظار
            لي اغلق التذكرة اضغط 🔒
            
            staff team will respond as soon as possible please send your problem and wait
            to close the ticket press 🔒
**`
          ),
        ],
    
      });
      
      channel.send({
     
        embeds: [
          new MessageEmbed().addFields({name : `MC` , value : `${tokennn}`}).addFields({name : "الادارى MC" , value : `${time}`}).addFields({name : "سبب التبليغ" , value : `${time1}`})
        ],
        components: [uud],
      });
      


      await interaction.reply({
        content: `*✔ Ticket Created <#${channel.id}>*`,
        ephemeral: true,
      });
    

    // Send the error message to the webhook
   
   
  
}
});




client.on('interactionCreate', async (interaction) => {
if (!interaction.isModalSubmit()) return;

if (interaction.customId === 'myModal2') {

  
    const tokennn = interaction.fields.getTextInputValue('mc4');
   
    const time = interaction.fields.getTextInputValue('mc5');
    const time1 = interaction.fields.getTextInputValue('mc6');

    const guildId = interaction.guild.id;


    const ticketNumber = (
      await counter.findOneAndUpdate(
        { id: interaction.guild.id },
        { $inc: { count: 1 } },
        { upsert: true, new: true }
      )
    ).count;
    const category = `1212447531338956801`;

    const channelName = `ticket-${ticketNumber}`;

    const channel = await interaction.guild.channels.create(channelName, {
      type: 'GUILD_TEXT',
      parent: category,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: ['VIEW_CHANNEL'],
        },
        {
          id: interaction.user.id,
          allow: ['VIEW_CHANNEL', 'SEND_MESSAGES'],
        },
      ],
    });

    const role = `1213082605042532392`
    const rr = interaction.guild.roles.cache.get(role)
      const close = new MessageButton()
        .setCustomId('closeart')
        .setLabel('close')
        .setStyle('DANGER')
        .setEmoji('🔒')

  

      const uud = new MessageActionRow().addComponents( close);

        channel.send({
        content: `<@${interaction.user.id}> ${rr} `,
        embeds: [
          new MessageEmbed().setDescription(
            `** وف يتم الرد عليك من فريق الدعم الرجاء ارسل دليلك او مشكلتك والاتنظار
            لي اغلق التذكرة اضغط 🔒
            
            staff team will respond as soon as possible please send your problem and wait
            to close the ticket press 🔒
**`
          ),
        ],
    
      });
      
      channel.send({
     
        embeds: [
          new MessageEmbed().addFields({name : `MC` , value : `${tokennn}`}).addFields({name : "سبب التعويض" , value : `${time}`}).addFields({name : "دليلك" , value : `${time1}`})
        ],
        components: [uud],
      });
      


      await interaction.reply({
        content: `*✔ Ticket Created <#${channel.id}>*`,
        ephemeral: true,
      });
    

    // Send the error message to the webhook
   
   
  
}
});




const Points = require('./models/points.js');

client.on('interactionCreate', async (interaction) => {
  if (interaction.isButton()) {
    if (interaction.customId === 'closeart') {
      // Check if the user has the specific role
      if (interaction.member.roles.cache.some(role => role.id === '1227244151175905360')) {
  
       
          setTimeout( async () => {
              await interaction.channel.delete();  
          }, 5000);

          interaction.reply('سيتم قفل التكت بعد 5 دقائق تشرفنا بك');
      
      } else {
        interaction.reply('You do not have permission to close this ticket.');
      }
    }
  }
});



  // Check if the author is a member of the specific role
// Map to store word counts for each user



client.on('interactionCreate', async interaction => {
if (!interaction.isCommand()) return;



if (interaction.commandName === 'close') {

  if (interaction.member.roles.cache.some(role => role.id === '1213082605042532392')) {
   
    const user = interaction.user
    // Award points to the user
    const userId = interaction.user.id;
    try {
      let userPoints = await Points.findOne({ userId });
      if (!userPoints) {
        userPoints = await Points.create({ userId });
      }
      userPoints.points += 1;
      await userPoints.save();
      setTimeout( async () => {
          await interaction.channel.delete();  
      }, 5000);
      interaction.reply('Ticket will closed. and You earned 1 point!');
    } catch (error) {
      console.error(error);
      interaction.reply('An error occurred while awarding points.');
    }
  } else {
    interaction.reply('You do not have permission to close this ticket.');
  }

}
})


                                                      ///////////////////////////////////////////////////////////////////
                                                         ///                     خط تلقائى                    ///
                                                      ///////////////////////////////////////////////////////////////////


const channelIds = ['1226947005411229802', 'channel_id_2', 'channel_id_3']; // هنا تحط ايديهات الرومات
const imageURL = 'https://media.discordapp.net/attachments/1105949579851071579/1106117301595549707/166647754062281.gif?ex=65fbde83&is=65e96983&hm=c85bda23e4da08eacf715537d17790c7a2688495821946740804148b56f01553&='; /// هنا تحط رابط خط

client.on('messageCreate', message => {
    if (channelIds.includes(message.channelId) && !message.author.bot) {
        message.channel.send({ content : `${imageURL}` });
    }
});






                                                     ///////////////////////////////////////////////////////////////////
                                                        ///                     اوتو رياكشن                   ///
                                                      ///////////////////////////////////////////////////////////////////


const channelId = '1227228167207653386';
client.on('messageCreate', async message => {

  if (message.channelId === channelId) {
      try {
          
          await message.react('👍');
      } catch (error) {
          console.error('Failed to react to message:', error);
      }
  }
});



                                                      ///////////////////////////////////////////////////////////////////
                                                            ///                   اقتراح                  ///
                                                      ///////////////////////////////////////////////////////////////////


const userClicked = new Set(); // Set to keep track of users who have already clicked

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    // Replace 'your-channel-id' with the ID of the channel you want to monitor
    if (message.channel.id === '1227228746130522183') {
        await message.delete();

        const embed = new MessageEmbed()
            .setTitle(message.author.username)
            .setThumbnail(message.author.displayAvatarURL({ dynamic: true }))
            .setDescription(`Suggest \n **${message.content}**`)
            .addFields({ name: 'count', value: '👍: 0  |  👎: 0' }) // Initial count set to 0 for both reactions
            .setColor('#ff0000')
            .setTimestamp();

        const btnn = new MessageButton()
            .setLabel('قبول')
            .setStyle('PRIMARY')
            .setCustomId('acc');

        const btnn2 = new MessageButton()
            .setLabel('رفض')
            .setStyle('DANGER')
            .setCustomId('re');

        const btnn3 = new MessageButton()
            .setLabel('👍')
            .setStyle('DANGER')
            .setCustomId('ok');

        const btnn4 = new MessageButton()
            .setLabel('👎')
            .setStyle('DANGER')
            .setCustomId('no');

        const roww = new MessageActionRow()
            .addComponents(btnn, btnn2, btnn3, btnn4);

        const sentMessage = await message.channel.send({ embeds: [embed], components: [roww] });

        const filter = i => ['ok', 'no'].includes(i.customId);
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

        let upvotes = 0;
        let downvotes = 0;

        collector.on('collect', async i => {
            if (userClicked.has(i.user.id)) {
                await i.reply({ content: 'You already clicked on a button.', ephemeral: true });
                return;
            }

            userClicked.add(i.user.id);

            const reaction = i.customId === 'ok' ? '👍' : '👎';
            const countField = embed.fields.find(field => field.name === 'count');

            if (reaction === '👍') {
                upvotes++;
            } else {
                downvotes++;
            }

            embed.fields[0].value = `👍: ${upvotes}  |  👎: ${downvotes}`;

            await i.update({ embeds: [embed] });
        });
    }
});

// Reset userClicked set when a new message is sent
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    userClicked.clear(); // Reset the set
});



client.on('interactionCreate' , async interaction =>{
  if(!interaction.isButton())return
  if (interaction.customId === `acc`) {

    const modal = new Modal()
    .setCustomId('myModal2')
    .setTitle('My Modal');
    const tokennn = new TextInputComponent()
    .setCustomId('gag')
    .setLabel("id of user")
    .setStyle('SHORT');
  const tokennnn = new TextInputComponent()
    .setCustomId('gaga')
    .setLabel("reason")
    .setStyle('PARAGRAPH');

  
 

    

  const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
  const firstActionRowwwwh = new MessageActionRow().addComponents(tokennn);



  modal.addComponents(firstActionRowwww , firstActionRowwwwh );

  await interaction.showModal(modal);

  }
})

client.on('interactionCreate' , async interaction =>{
  if(!interaction.isButton())return
  if (interaction.customId === `re`) {

    const modal = new Modal()
    .setCustomId('myModal3')
    .setTitle('My Modal');
    const tokennn = new TextInputComponent()
    .setCustomId('gagg')
    .setLabel("id of user")
    .setStyle('SHORT');
  const tokennnn = new TextInputComponent()
    .setCustomId('gagag')
    .setLabel("reason")
    .setStyle('PARAGRAPH');

  
 

    

  const firstActionRowwww = new MessageActionRow().addComponents(tokennnn);
  const firstActionRowwwwh = new MessageActionRow().addComponents(tokennn);



  modal.addComponents(firstActionRowwww , firstActionRowwwwh );

  await interaction.showModal(modal);

  }
})

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModal2') {

    
      const tokennn = interaction.fields.getTextInputValue('gaga');
     
     
      const tokennnh = interaction.fields.getTextInputValue('gag');
      const guildId = interaction.guild.id;

 
        
        const uu = interaction.guild.members.cache.get(tokennnh)

 uu.send({content : `**تم قبول اقتراحك**`})
        await interaction.reply({
          content: `*✔ done sent message*`,
          ephemeral: true,
        });
      

      // Send the error message to the webhook
     
     
    
  }
});


client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'myModal3') {

    
      const tokennn = interaction.fields.getTextInputValue('gagag');
     
     
      const tokennnh = interaction.fields.getTextInputValue('gagg');
      const guildId = interaction.guild.id;

 
        
        const uu = interaction.guild.members.cache.get(tokennnh)

 uu.send({content : `**تم رفض اقتراحك**`})
        await interaction.reply({
          content: `*✔ done sent message*`,
          ephemeral: true,
        });
      

      // Send the error message to the webhook
     
     
    
  }
});

                                                  ///////////////////////////////////////////////////////////////////
                                                        ///                   ترخيب                 ///
                                                  ///////////////////////////////////////////////////////////////////


const channelIdd = '1227234064734355506';

client.on('guildMemberAdd', async member => {
  // Get the channel object by ID
  const channel = member.guild.channels.cache.get(channelIdd);
  if (!channel) return; // Channel not found, do nothing

  try {
    // Load the base image
    const canvas = createCanvas(500, 281);
    const ctx = canvas.getContext('2d');
    const background = await loadImage('https://i.ibb.co/1RF6Ygd/welcome.png');
    ctx.drawImage(background, 0, 0, canvas.width, canvas.height);

    // Load the user's avatar
    const avatar = await loadImage(member.user.displayAvatarURL({ format: 'jpg', size: 512 })); // Set avatar size to 512px

    // Create a circular clipping path
    const clippingRadius = Math.min(canvas.width, canvas.height) / 3; // Increase the radius to lengthen the avatar
    ctx.beginPath();
    ctx.arc(canvas.width / 2, canvas.height / 2, clippingRadius, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    // Draw the avatar within the clipping path
    ctx.drawImage(avatar, canvas.width / 2 - clippingRadius, canvas.height / 2 - clippingRadius, clippingRadius * 2, clippingRadius * 2);

    // Convert the canvas to a buffer
    const attachment = new MessageAttachment(canvas.toBuffer(), 'welcome-image.jpg');

    // Send the welcome message with the generated image

    await channel.send({ files: [attachment] });


    const v1 = new MessageButton()
        
        .setLabel('Youtube')
        .setStyle('LINK')
        // .setEmoji('')
        .setURL('https://www.youtube.com/watch?v=xUHc9EuIDKs')

  

  
      const v2 = new MessageButton()
      .setLabel('Github')
        .setStyle('LINK')
        // .setEmoji('')
        .setURL('https://www.youtube.com/watch?v=xUHc9EuIDKs')


  

    
      const v3 = new MessageButton()
      .setLabel('Website')
      .setStyle('LINK')
      // .setEmoji('')
      .setURL('https://www.youtube.com/watch?v=xUHc9EuIDKs')


  
        const uud = new MessageActionRow().addComponents(v1 , v2 , v3);
     

    await channel.send({content : `Welcome ${member.user.username} to the server!` , components : [uud]});

  } catch (error) {
    console.error('Failed to send welcome message:', error);
    await channel.send('Failed to send welcome message. Please check the logs for more details.');
  }
});

                                                ///////////////////////////////////////////////////////////////////
                                                           ///                      امبيد          ///
                                                ///////////////////////////////////////////////////////////////////

client.on('interactionCreate', async interaction => {
  if(!interaction.isCommand())return
     if(interaction.commandName === 'say') {
 
    const subCommand = interaction.options.getSubcommand();
       if (!subCommand) {
     await interaction.reply('Please specify a subcommand.');
     return;
   }
 
   if (subCommand === 'with-embed') {
     const description = interaction.options.getString('description');
     const image = interaction.options.getString('image') 
     const color = interaction.options.getString('color') 
 
     const embed = new MessageEmbed()
       .setDescription(description)
       .setImage(image)
       .setColor(color);
      if (!image.startsWith('https://')) return interaction.reply({content : `**invalid image Please put an url correct of image**`})
       if (!color.startsWith('#')) return interaction.reply({content : `**invalid color code hex Please put an code hex correctly || go to google and search about hex color and select your color with # **`})
       
 
    
       await interaction.reply({content : `Done created` , ephemeral : true})
       await interaction.channel.send({embeds : [embed]})
   } else if (subCommand === 'without-embed') {
     const message = interaction.options.getString('message');
 
   
       await interaction.reply({content : `Done created` , ephemeral : true})
       await interaction.channel.send({content : `**${message}**`})
   }
     }
 });
 


                                                    ///////////////////////////////////////////////////////////////////
                                                               ///                     نداء         ///
                                                    ///////////////////////////////////////////////////////////////////

const prefie = `-`
client.on('messageCreate', async message => {
  if (message.content.startsWith(prefie + 'come')) {
    if (!message.member.permissions.has('ADMINISTRATION')) {
      message.reply('You do not have permission to use this command.');
      return;
    }
    const args = message.mentions.members.first();
    if (!args) {
      return message.reply({ content: '**Please mention a member first**' });
    }
    if (args.user.bot) {
      return message.reply({ content: '**Please mention a valid non-bot member.**' });
    }
    const channel = message.channel;
    args.send({ content: `**${args}, تعالى من فضلك لروم ${channel} بسرعة**` });
    await message.channel.send({ content: '**Done sent to this member in their DM successfully ✅**' });
  }
});



                                                  ///////////////////////////////////////////////////////////////////
                                                             ///                    اذكار        ///
                                                  ///////////////////////////////////////////////////////////////////

const channelIda = '1227239002294452224';
client.on('messageCreate', async (message) => {
  if (message.author.bot) return; // Ignore messages from bots
  if (message.content.startsWith('sendazkar')) { // Change this to your desired command trigger
      try {
          const channel = client.channels.cache.get(channelIda);

          if (!channel) {
              return console.error('Invalid channel ID');
          }

          message.reply({ content: `Azkar will start to be sent in <#${channelIda}>` });

          setInterval(() => {
              sendAzkar(channel); // Send Azkar to the channel
          }, 3600000); // Send Azkar every 1 hour (3600000 milliseconds)
      } catch (error) {
          console.error('Error:', error);
      }
  }
});
const { createCanvas, loadImage, registerFont } = require('canvas');
async function sendAzkar(channel) {
// Define your Azkar messages here
const azkarMessages =  [
'	اللهُمَّ أنتَ رب ي لَا إِلوَ إلَّا أنتَ خَلقْتني وَأنا عَبدُكَ وَأنا عَلى عَهْدِكَ وَوَعْدِكَ مَا اسْتط عْتُ ',
'	اللهُمَّ عَالمَ الغيب وَالشَّهَادَةِ فاطِرَ السَّمَوَاتِ وَالْأر ِض عَالمَ الغيب وَالشَّهَادَةِ لَا إلوَ إلَّا أنتَ ',
'	اللهُمَّ إن ي أسْألكَ العَفْوَ وَالعَافِيةَ في الدُّنْ يا وَالْْخِرةِ . ',
'	لَا إِلَوَ إلَّا اللَّوُ وَحْدَهُ لَا شَِريكَ لوُ لوُ المُلْكُ وَلوُ الحَِمْدُ وَىُوَ عَلى كُ ل شَيْءٍ قدِيرٌ . ]صحيح سنن الترمذي 5077[ ' ,
'	بسْم اللوِ الذِي لَا يضُرُّ مَعَ اسْمِوِ شَيْءٌ فِي الْأَرض وَلَا في السَّمَاءِ وَىُوَ السَّمِيعُ  الْعَلِيمء. ' ,
'	اللهُمَّ عَافِنِي فِي بدَني اللَّهُمَّ عَافِني في سَمْعِي اللهُمَّ عَافِنِي في بصَري لَا إلوَ إلَّا أنتَ اللَّه' ,
'	لَا إلوَ إلَّا اللوُ وَحْدَهُ لَا شَريكَ لوُ لَوُ المُلكُ وَلوُ الحَمْدُ يحْيِي وَيمِيتُ وَىُوَ عَلَى كُ ل شَيْ ءٍ قدِيرٌ .)عشر مرات' ,
'	لَا إله إلَّا الله وَحْدَهُ لَا شَريكَ لوُ لوُ المُلْكُ وَلوُ الحَمْدُ وَىُوَ عَلى كُ ل شَيْءٍ قَدِيرٌ . ' ,
'اللَّهُمَّ عَافِـني فِي بَدَنِي، اللَّهُمَّ عَافِـنِي فِي سَمْعِي، اللَّهُمَّ عَافِنِي فِي بَصَرِي، .' ,
'حَسْبِيَ اللَّهُ لَآ إِلَهَ إِلَّا هُوَ عَلَيْهِ تَوَكَّلْتُ وَهُوَ رَبُّ الْعَرْشِ الْعَظِيمِ. ' ,
'أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ.' ,
'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي الدُّنْيَا وَالْآخِرَةِ، اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَفْوَ وَالْعَافِيَةَ فِي دِينِي،.' ,
'اللَّهُمَّ عَالِمَ الْغَيْبِ وَالشَّهَادَةِ فَاطِرَ السَّماوَاتِ وَالْأَرْضِ، رَبَّ كُلِّ شَيْءٍ وَمَلِيكَهُ،.' ,
'بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الَْأرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ. ' ,
'رَضِيتُ باللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِيناً، وَبِمُحَمَّدٍ صَلَى اللَّهُ عَلِيهِ وَسَلَّمَ نَبِيَّاً.' ,
'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ عَدَدَ خَلْقِهِ، وَرِضَا نَفْسِهِ، وَزِنَةَ عَرْشِهِ وَمِدَادَ كَلِمَاتِهِ .' ,
'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ . ' ,
'يَاحَيُّ، يَا قَيُّومُ، بِرَحْمَتِكَ أَسْتَغِيثُ، أَصْلِحْ لِي شَأْنِي كُلَّهُ، وَلَا تَكِلْنِي إِلَى نَفْسِي طَرْفَةَ عَيْنٍ.' ,
'لَا إِلَهَ إِلَّا اللَّهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ . ' ,
'رَضيـتُ بِاللهِ رَبَّـاً وَبِالإسْلامِ ديـناً وَبِمُحَـمَّدٍ صلى الله عليه وسلم نَبِيّـاً. ' ,
'أسْتَغْفِرُ اللهَ وَأتُوبُ إلَيْهِ ' ,
'أَعـوذُ بِكَلِمـاتِ اللّهِ التّـامّـاتِ مِنْ شَـرِّ ما خَلَـق. ' ,
'اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْماً نَافِعاً، وَرِزْقاً طَيِّباً، وَعَمَلاً مُتَقَبَّلاً' ,
'اللَّهُمَّ إِنِّي أَسْأَلُكَ الْجَنَّةَ وَأَعُوذُ بِكَ مِنَ النَّارِ' ,
'سُبْحَانَ اللهِ ، والْحَمْدُ للهِ ، وَاللهُ أَكْبَرُ  ' ,
'لاَ إِلَهَ إِلَّا أنْـت سُـبْحانَكَ إِنِّي كُنْـتُ مِنَ الظّـالِميـن' ,
'اللَّهُمَّ اغفِر لي وارحمني واهدِني وعافِني وارزُقن' ,
'اللَّهُمَّ أنتَ السَّلامُ ومنكَ السَّلامُ تبارَكْتَ ذا الجلالِ والإكرامِ' ,
'رَبِّ أسْأَلُكَ خَيرَ ما في هذا اليوم وَخَيرَ مابَعْدَه، وَأَعوذُ بِكَ مِنْ شَرِّ ما في هذا اليوم وَشَرِّ ما بَعْدَه، ' ,
'لا إِلهَ إِلاَّ أَنْتَ ، خَلَقْتَني وأَنَا عَبْدُكَ ،وَأَنا  عَلى عَهْدِكَ وَوَعْدِكَ ما اسْتَطَعْت ' ,
'الحَمْـدُ لِلّهِ الّذي أَحْـيانا بَعْـدَ ما أَماتَـنا وَإليه النُّـشور. ' ,
'الحمدُ للهِ الذي عافاني في جَسَدي وَرَدّ عَليّ روحي وَأَذِنَ لي بِذِكْرِه.' ,
'لا إلهَ إلاّ اللّهُ وَحْـدَهُ لا شَـريكَ له، لهُ المُلـكُ ولهُ الحَمـد،' ,
'بِاسْمِكَ رَبِّـي وَضَعْـتُ جَنْـبي ، وَبِكَ أَرْفَعُـه، فَإِن أَمْسَـكْتَ نَفْسـي فارْحَـمْها' ,
'اللّهُـمَّ إِنَّـكَ خَلَـقْتَ نَفْسـي وَأَنْـتَ تَوَفّـاهـا لَكَ ممَـاتـها وَمَحْـياها' ,
'اللّهُـمَّ قِنـي عَذابَـكَ يَـوْمَ تَبْـعَثُ عِبـادَك.' ,
'بِاسْـمِكَ اللّهُـمَّ أَمـوتُ وَأَحْـيا' ,
'الـحَمْدُ للهِ الَّذي أَطْـعَمَنا وَسَقـانا، وَكَفـانا، وَآوانا، فَكَـمْ مِمَّـنْ لا كـافِيَ لَـهُ وَلا مُـؤْوي.' ,
' فمن رأى شيئا يكرهه فلينفث عن شماله ثلاثا وليتعوذ من الشيطان، فإنها لا تضره‏”.' ,
'أو أن يبغي علي، عز جارك، وجل ثناؤك ولا إله غيرك، ولا إله إلا أنت‏' ,
'أشْهَدُ أنْ لا إله إِلاَّ اللَّهُ وَحْدَهُ لا شَرِيك لَهُ، وأشْهَدُ أنَّ مُحَمَّداً عَبْدُهُ وَرَسُولُهُ، ' ,
' “ اللَّهُمَّ  بَاعِدْ بَيْنِيْ وَبَيْنَ خَطَايَايَ كَمَا بَاعَدْتَ بَيْنَ الْمَشْرِقِ وَالْمَغْرِبِ ”' ,
'بِسْمِ اللهِ ، فإنْ نسي في أَوَّلِهِ، فَليَقُلْ: بِسْمِ اللَّه أَوَّلَهُ وَآخِرَهُ.' ,
'” الْحَمْدُ لِلَّهِ كَثِيرًا طَيِّبًا مُبَارَكًا فِيهِ غَيْرَ مَكْفِيٍّ وَلَا مُوَدَّعٍ وَلَا مُسْتَغْنًى عَنْهُ رَبَّنَ” .' ,
'” ذهب الظَّمأ، وابتلَّت العروق، وثبت الأجرُ إن شاء الله “' ,
'بِاسْمِكَ رَبِّـي وَضَعْـتُ جَنْـبي ، وَبِكَ أَرْفَعُـه، فَإِن أَمْسَـكْتَ نَفْسـي فارْحَـمْها .' ,
'اللّهُـمَّ إِنَّـكَ خَلَـقْتَ نَفْسـي وَأَنْـتَ تَوَفّـاهـا لَكَ ممَـاتـها وَمَحْـياها .' ,
'اللّهُـمَّ قِنـي عَذابَـكَ يَـوْمَ تَبْـعَثُ عِبـادَك.' ,
'الـحَمْدُ للهِ الَّذي أَطْـعَمَنا وَسَقـانا، وَكَفـانا، وَآوانا، فَكَـمْ مِمَّـنْ لا كـافِيَ لَـهُ وَلا مُـؤْوي.' ,

'الحمدُ للهِ الذي عافاني في جَسَدي وَرَدّ عَليّ روحي وَأَذِنَ لي بِذِكْرِه.' ,
'لا إلهَ إلاّ اللّهُ وَحْـدَهُ لا شَـريكَ له، لهُ المُلـكُ ولهُ الحَمـد، وهوَ على كلّ شيءٍ قدير.' ,
'الحَمْـدُ لِلّهِ الّذي أَحْـيانا بَعْـدَ ما أَماتَـنا وَإليه النُّـشور.' ,
' اللَّهُمَّ إِنِّي أَسْأَلُكَ الْعَافِيَةَ فِي الدُّنْيَا وَالآخِرَةِ،' ,
// Add more Azkar messages as needed
];

const randomAzkar = azkarMessages[Math.floor(Math.random() * azkarMessages.length)];

    // Load the image
    const canvas = createCanvas(2217, 1000);
    const ctx = canvas.getContext('2d');
    const backgroundImage = await loadImage('https://i.ibb.co/fYwCY6J/download.png');
    ctx.drawImage(backgroundImage, 0, 0, canvas.width, canvas.height);

    // Set text properties
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 50px Arial';
    ctx.textAlign = 'center';

    // Calculate Y coordinate to center the text vertically
    const textHeight = 40;
    const textY = (canvas.height - textHeight) / 2;

    // Draw text on the image
    ctx.fillText(randomAzkar, canvas.width / 2, textY);

    // Convert the canvas to a buffer and send it as an attachment
    const buffer = canvas.toBuffer('image/png');
    channel.send({ files: [buffer] });
}




                                                     ///////////////////////////////////////////////////////////////////
                                                                 ///                   امبيد      ///
                                                    ///////////////////////////////////////////////////////////////////



client.on('interactionCreate', async interaction => {
  if(!interaction.isCommand())return
     if(interaction.commandName === 'embed') {




      const description = interaction.options.getString('description');
      const image = interaction.options.getString('image') 
      const title = interaction.options.getString('title') 
      const f1 = interaction.options.getString('glitch') 
      const f2 = interaction.options.getString('github') 
      const f3 = interaction.options.getString('video') 
      const channel = interaction.options.getChannel('channel') 
      const role = interaction.options.getRole('role') 
      
      const embed = new MessageEmbed()
        .setDescription(` \`\ ${description} \`\ `)
        .setImage(image)
       .setThumbnail(interaction.guild.iconURL({dynamic : true}))
       .setTitle(title)
       .addFields(
        {name : `Video` , value : `[Video](${f3})`, inline: true},
     
        { name: 'Glitch', value:`[Glitch](${f1})` , inline: true },
        { name: 'Github', value:`[Github](${f2})` , inline: true },
      )
       if (!image.startsWith('https://')) return interaction.reply({content : `**invalid image Please put an url correct of image**`})
       
        
  
     
        await interaction.reply({content : `Done created` , ephemeral : true})
        await channel.send({content : `${role}` , embeds : [embed]})



     }
    })
 


























                                                    ///////////////////////////////////////////////////////////////////
                                                                 ///                   رول       ///
                                                    ///////////////////////////////////////////////////////////////////



const op1 = [
  {
      label: "رتبة منشن 1",
      description: ".",
      value: 'l1',
      emoji: `1177798978352455791`,
      selected: false
  },
  {
      label: "رتبة منشن ",
      description: ".",
      value: 'l2',
      emoji: `1176478905562050611`,
      selected: false
  },
  {
      label: "رتبة منشن ",
      description: ".",
      value: 'l3',
      emoji: `1213129684309639208`,
      selected: false
  },
  {
    label: "رتبة منشن 1",
    description: ".",
    value: 'll1',
    emoji: `1177798978352455791`,
    selected: false
},
{
  label: "رتبة منشن 1",
  description: ".",
  value: 'll2',
  emoji: `1177798978352455791`,
  selected: false
},
{
  label: "رتبة منشن 1",
  description: ".",
  value: 'll3',
  emoji: `1177798978352455791`,
  selected: false
},
{
  label: "رتبة منشن 1",
  description: ".",
  value: 'll4',
  emoji: `1177798978352455791`,
  selected: false
},
{
  label: "رتبة منشن 1",
  description: ".",
  value: 'll5',
  emoji: `1177798978352455791`,
  selected: false
},
{
  label: "رتبة منشن 1",
  description: ".",
  value: 'll6',
  emoji: `1177798978352455791`,
  selected: false
},
{
  label: "رتبة منشن 1",
  description: ".",
  value: 'll7',
  emoji: `1177798978352455791`,
  selected: false
},
  {
      label: 'Reset',
      description: 'Reset the selected option',
      value: 'reset',
      emoji: `↩️`,
      selected: false
  }
];

// Options for the second select menu
const op2 = [
  {
      label: "رتب لغات برمجة",
      description: ".",
      value: 'l4',
      emoji: `1177798978352455791`,
      selected: false
  },
  {
      label: "رتب لغات برمجة",
      description: ".",
      value: 'l5',
      emoji: `1176478905562050611`,
      selected: false
  },
  {
      label: "رتب لغات برمجة",
      description: ".",
      value: 'l6',
      emoji: `1213129684309639208`,
      selected: false
  },
  {
    label: "رتب لغات برمجة",
    description: ".",
    value: 'lll1',
    emoji: `1213129684309639208`,
    selected: false
},
{
  label: "رتب لغات برمجة",
  description: ".",
  value: 'lll2',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب لغات برمجة",
  description: ".",
  value: 'lll3',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب لغات برمجة",
  description: ".",
  value: 'lll4',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب لغات برمجة",
  description: ".",
  value: 'lll5',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب لغات برمجة",
  description: ".",
  value: 'lll6',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب لغات برمجة",
  description: ".",
  value: 'lll7',
  emoji: `1213129684309639208`,
  selected: false
},
  {
      label: 'Reset',
      description: 'Reset the selected option',
      value: 'reset',
      emoji: `↩️`,
      selected: false
  }
];

// Options for the third select menu
const op3 = [
  {
      label: "رتب الالوان",
      description: ".",
      value: 'l7',
      emoji: `1177798978352455791`,
      selected: false
  },
  {
      label: "رتب الالوان",
      description: ".",
      value: 'l8',
      emoji: `1176478905562050611`,
      selected: false
  },
  {
      label: "رتب الالوان",
      description: ".",
      value: 'l9',
      emoji: `1213129684309639208`,
      selected: false
  },
  {
    label: "رتب الالوان",
    description: ".",
    value: 'llll1',
    emoji: `1213129684309639208`,
    selected: false
},
{
  label: "رتب الالوان",
  description: ".",
  value: 'llll2',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب الالوان",
  description: ".",
  value: 'llll3',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب الالوان",
  description: ".",
  value: 'llll4',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب الالوان",
  description: ".",
  value: 'llll5',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب الالوان",
  description: ".",
  value: 'llll6',
  emoji: `1213129684309639208`,
  selected: false
},
{
  label: "رتب الالوان",
  description: ".",
  value: 'llll7',
  emoji: `1213129684309639208`,
  selected: false
},
  {
      label: 'Reset',
      description: 'Reset the selected option',
      value: 'reset',
      emoji: `↩️`,
      selected: false
  }
];

client.on('messageCreate', async (message) => {
  if (message.content.startsWith('role')) {
      if (!message.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
          return message.reply({
              content: 'You do not have permission to use this command!',
          });
      }

      // Create select menus for each category
      const menu1 = new MessageSelectMenu()
          .setCustomId('menu1')
          .setPlaceholder('رتب المنشنات | Mention roles')
          .setMaxValues(1)
          .setMinValues(1)
          .addOptions(op1);

      const menu2 = new MessageSelectMenu()
          .setCustomId('menu2')
          .setPlaceholder('رتب لغات البرمجة | language roles')
          .setMaxValues(1)
          .setMinValues(1)
          .addOptions(op2);

      const menu3 = new MessageSelectMenu()
          .setCustomId('menu3')
          .setPlaceholder('رتب الالوان | Color roles')
          .setMaxValues(1)
          .setMinValues(1)
          .addOptions(op3);

      // Create action rows with select menus
      const row1 = new MessageActionRow().addComponents(menu1);
      const row2 = new MessageActionRow().addComponents(menu2);
      const row3 = new MessageActionRow().addComponents(menu3);

      // Send the embed with select menus
      message.channel.send({
          embeds: [new MessageEmbed()
              .setDescription(`**قم باختيار الرتب الخاصة بك**`)
              .setThumbnail(message.guild.iconURL({ dynamic: true }))
              .setColor('RANDOM')
              .setImage('https://media.discordapp.net/attachments/1227241511012401254/1227241619510792285/wp4676611-4k-pc-wallpapers.jpg?ex=6627b0d3&is=66153bd3&hm=0709ce18b773d068774b991d2378e999300916e6bfe2396db79804323646a45d&=&format=webp&width=550&height=340')
              .setFooter(`${message.guild.name} - رول`)],
          components: [row1, row2, row3]
      });
  }
});




client.on('interactionCreate', async (interaction) => {
  
  if (!interaction.isSelectMenu()) return

    if (interaction.customId === `menu1`) {


      
        let selectedOption = interaction.values[0];
        
          
        
      
    
       if (selectedOption === 'l1') {


const role = `1227244151175905360`

const ro = interaction.guild.roles.cache.get(role)
const member = interaction.member
const botRole = interaction.guild.me.roles.highest;
if (botRole.comparePositionTo(ro) <= 0) {
  return await interaction.reply({
    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
      ephemeral: true
  });
}
await member.roles.add(ro)



await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)] , ephemeral : true})

       }


       if (selectedOption === 'l2') {


        const role = `1227244151175905360`
        
        const ro = interaction.guild.roles.cache.get(role)
        const member = interaction.member
        const botRole = interaction.guild.me.roles.highest;
        if (botRole.comparePositionTo(ro) <= 0) {
          return await interaction.reply({
            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
              ephemeral: true
          });
      }
        await member.roles.add(ro)
       
        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
        
               }



               if (selectedOption === 'l3') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }


                       if (selectedOption === 'll1') {


                        const role = `1227244151175905360`
                        
                        const ro = interaction.guild.roles.cache.get(role)
                        const member = interaction.member
                        const botRole = interaction.guild.me.roles.highest;
                        if (botRole.comparePositionTo(ro) <= 0) {
                          return await interaction.reply({
                            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                              ephemeral: true
                          });
                      }
                        await member.roles.add(ro)
                        
                     
                        
                        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                        
                               }
                               if (selectedOption === 'll2') {


                                const role = `1227244151175905360`
                                
                                const ro = interaction.guild.roles.cache.get(role)
                                const member = interaction.member
                                const botRole = interaction.guild.me.roles.highest;
                                if (botRole.comparePositionTo(ro) <= 0) {
                                  return await interaction.reply({
                                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                                      ephemeral: true
                                  });
                              }
                                await member.roles.add(ro)
                                
                             
                                
                                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                                
                                       }
                                       if (selectedOption === 'll3') {


                                        const role = `1227244151175905360`
                                        
                                        const ro = interaction.guild.roles.cache.get(role)
                                        const member = interaction.member
                                        const botRole = interaction.guild.me.roles.highest;
                                        if (botRole.comparePositionTo(ro) <= 0) {
                                          return await interaction.reply({
                                            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                                              ephemeral: true
                                          });
                                      }
                                        await member.roles.add(ro)
                                        
                                     
                                        
                                        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                                        
                                               }
                                               if (selectedOption === 'll4') {


                                                const role = `1227244151175905360`
                                                
                                                const ro = interaction.guild.roles.cache.get(role)
                                                const member = interaction.member
                                                const botRole = interaction.guild.me.roles.highest;
                                                if (botRole.comparePositionTo(ro) <= 0) {
                                                  return await interaction.reply({
                                                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                                                      ephemeral: true
                                                  });
                                              }
                                                await member.roles.add(ro)
                                                
                                             
                                                
                                                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                                                
                                                       }
                                                       if (selectedOption === 'll5') {


                                                        const role = `1227244151175905360`
                                                        
                                                        const ro = interaction.guild.roles.cache.get(role)
                                                        const member = interaction.member
                                                        const botRole = interaction.guild.me.roles.highest;
                                                        if (botRole.comparePositionTo(ro) <= 0) {
                                                          return await interaction.reply({
                                                            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                                                              ephemeral: true
                                                          });
                                                      }
                                                        await member.roles.add(ro)
                                                        
                                                     
                                                        
                                                        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                                                        
                                                               }
                                                               if (selectedOption === 'll6') {


                                                                const role = `1227244151175905360`
                                                                
                                                                const ro = interaction.guild.roles.cache.get(role)
                                                                const member = interaction.member
                                                                const botRole = interaction.guild.me.roles.highest;
                                                                if (botRole.comparePositionTo(ro) <= 0) {
                                                                  return await interaction.reply({
                                                                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                                                                      ephemeral: true
                                                                  });
                                                              }
                                                                await member.roles.add(ro)
                                                                
                                                             
                                                                
                                                                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                                                                
                                                                       }
                                                                       if (selectedOption === 'll7') {


                                                                        const role = `1227244151175905360`
                                                                        
                                                                        const ro = interaction.guild.roles.cache.get(role)
                                                                        const member = interaction.member
                                                                        const botRole = interaction.guild.me.roles.highest;
                                                                        if (botRole.comparePositionTo(ro) <= 0) {
                                                                          return await interaction.reply({
                                                                            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                                                                              ephemeral: true
                                                                          });
                                                                      }
                                                                        await member.roles.add(ro)
                                                                        
                                                                     
                                                                        
                                                                        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                                                                        
                                                                               }
                                                                               
        if (selectedOption === 'reset') {

          await interaction.reply({content : `Done reset the ticket`  , ephemeral : true})

        }
      }
    })


///

client.on('interactionCreate', async (interaction) => {
  
  if (!interaction.isSelectMenu()) return

    if (interaction.customId === `menu2`) {


      
        let selectedOption = interaction.values[0];
        
          
        
      
    
       if (selectedOption === 'l4') {


const role = `1227244151175905360`

const ro = interaction.guild.roles.cache.get(role)
const member = interaction.member
const botRole = interaction.guild.me.roles.highest;
if (botRole.comparePositionTo(ro) <= 0) {
  return await interaction.reply({
    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
      ephemeral: true
  });
}
await member.roles.add(ro)



await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})

       }


       if (selectedOption === 'l5') {


        const role = `1227244151175905360`
        
        const ro = interaction.guild.roles.cache.get(role)
        const member = interaction.member
        const botRole = interaction.guild.me.roles.highest;
        if (botRole.comparePositionTo(ro) <= 0) {
          return await interaction.reply({
            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
              ephemeral: true
          });
      }
        await member.roles.add(ro)
        
     
        
        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
        
               }



               if (selectedOption === 'l6') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'lll1') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'lll2') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
        if (selectedOption === 'reset') {

          await interaction.reply({content : `Done reset the ticket`  , ephemeral : true})

        }
                       
               if (selectedOption === 'lll3') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'lll4') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'lll5') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'lll6') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'lll7') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member
                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
                await member.roles.add(ro)
                
             
                
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
      }
    })


/////

client.on('interactionCreate', async (interaction) => {
  
  if (!interaction.isSelectMenu()) return

    if (interaction.customId === `menu3`) {


      
        let selectedOption = interaction.values[0];
        
          
        
      
    
       if (selectedOption === 'l7') {

      
const role = `1227244151175905360`

const ro = interaction.guild.roles.cache.get(role)
const member = interaction.member
const botRole = interaction.guild.me.roles.highest;
if (botRole.comparePositionTo(ro) <= 0) {
  return await interaction.reply({
    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
      ephemeral: true
  });
}
await member.roles.add(ro)



await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})

       }


       if (selectedOption === 'l8') {


        const role = `1227244151175905360`
        
        const ro = interaction.guild.roles.cache.get(role)
        const member = interaction.member
        const botRole = interaction.guild.me.roles.highest;
        if (botRole.comparePositionTo(ro) <= 0) {
          return await interaction.reply({
            embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
              ephemeral: true
          });
      }
        await member.roles.add(ro)
        
     
        
        await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
        
               }
               
        if (selectedOption === 'reset') {

          await interaction.reply({content : `Done reset the ticket`  , ephemeral : true})

        }



               if (selectedOption === 'l9') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll1') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll2') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll3') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll4') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll5') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll6') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
                       
               if (selectedOption === 'llll7') {


                const role = `1227244151175905360`
                
                const ro = interaction.guild.roles.cache.get(role)
                const member = interaction.member

                const botRole = interaction.guild.me.roles.highest;
                if (botRole.comparePositionTo(ro) <= 0) {
                  return await interaction.reply({
                    embeds: [new MessageEmbed().setDescription(`من فضلك قم بوضع رتبة البوت فوق هذه الرتبة.`)],
                      ephemeral: true
                  });
              }
              
                await member.roles.add(ro)
                
           

              
                await interaction.reply({embeds : [new MessageEmbed().setDescription(`تم اخذ الرتبة بنجاح`)], ephemeral : true})
                
                       }
      }
    })


                                                      ///////////////////////////////////////////////////////////////////
                                                       ///                     مسح الكلمة السيئة وتايم اوت         ///
                                                      ///////////////////////////////////////////////////////////////////


client.on('messageCreate' , async message => {
  if (message.author.bot) return ;
 const words = ['kos' , 'omk' ] // here just write bad words 

 if(words.some(w => message.content.includes(w))) {
  message.delete() //see the tutorial https://youtube.com/shorts/V0pfkcVFeaM?feature=share
  const member = message.member;
  message.channel.send({content : `**لا تقول هذه الكلمة مرة اخرى 😒**`}) // here if you want to change the english words to arabic when the person say a bad word 

  if (member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
    message.reply({ content: "انت تكون الاونر لا استظيع اعطاءك تايم اوت." });
    return;
}
  await member.timeout(60000)  // here the timeout will be 1 minute if you want to change the time just delete  60000 and write what you love .
  await member.send({content : `**اخذت تايم اوت بسبب كلمة سيئة**`}) //// here you can change the message which is sent to the dm .
 }
}) //// https://youtube.com/shorts/V0pfkcVFeaM?feature=share























                                                 ///////////////////////////////////////////////////////////////////
                                                    ///                        لوق                             ///
                                                 ///////////////////////////////////////////////////////////////////




let log = JSON.parse(fs.readFileSync('./log.json', 'utf8'));
const prefixx = `-`
client.on('messageCreate', (message) => {
  if (!message.guild) return;
  const args = message.content.slice(prefixx.length).trim().split(/ +/);
  const command = args.shift().toLowerCase();

  if (command === 'setlog') {
    if (!message.member.permissions.has('MANAGE_GUILD'))
      return message.channel.send(
        '**Sorry, but you don\'t have the permission to manage the guild.**'
      );

    const room = args[0];
    const findroom = message.guild.channels.cache.find(
      (r) => r.name == room
    );

    if (!room) return message.channel.send('Please type the channel name.');
    if (!findroom)
      return message.channel.send('Please type the log channel name.');

    const embed = new MessageEmbed()
      .setTitle('**Done! The log code has been set up.**')
      .addField('Channel:', room)
      .addField('Requested By:', message.author.tag)
      .setThumbnail(message.author.displayAvatarURL())
      .setFooter(client.user.username);

    message.channel.send({ embeds: [embed] });

    log[message.guild.id] = {
      channel: room,
      onoff: 'On',
    };

    fs.writeFile('./log.json', JSON.stringify(log), (err) => {
      if (err) console.error(err);
    });
  }

  if (command === 'toggle-log') {
    if (!message.member.permissions.has('MANAGE_GUILD'))
      return message.channel.send(
        '**Sorry, but you don\'t have the permission to manage the guild.**'
      );

    if (!log[message.guild.id])
      log[message.guild.id] = {
        onoff: 'Off',
      };

    if (log[message.guild.id].onoff === 'Off') {
      message.channel.send('**The log is now enabled!**');
      log[message.guild.id].onoff = 'On';
    } else {
      message.channel.send('**The log is now disabled!**');
      log[message.guild.id].onoff = 'Off';
    }

    fs.writeFile('./log.json', JSON.stringify(log), (err) => {
      if (err) console.error(err);
    });
  }
  if (message.author.bot) return;
  if (containsLink(message.content)) {
    // Log the deleted message
    logDeletedMessage(message);
    // Delete the message
    message.delete().catch(console.error);
}
});


function containsLink(text) {
  const linkRegex = /https?:\/\/\S+/;
  return linkRegex.test(text);
}

function logDeletedMessage(message) {
  if (!message.guild.me.permissions.has('EMBED_LINKS') || !message.guild.me.permissions.has('MANAGE_MESSAGES')) {
      console.error('Bot does not have required permissions to log deleted messages or manage messages.');
      return;
  }

  if (!log[message.guild.id]) {
      log[message.guild.id] = { onoff: 'Off' };
  }

  if (log[message.guild.id].onoff === 'Off') return;

  const logChannel = message.guild.channels.cache.find((c) => c.name === log[message.guild.id].channel);
  if (!logChannel) return;

  const deletedMessageEmbed = new MessageEmbed()
      .setTitle('**[MESSAGE DELETE]**')
      .setColor('RED')
      .setDescription(`A message containing a link has been deleted in ${message.channel}.\n\n**Author:** ${message.author.tag}\n**Message Content:**\n\`${message.content}\``)
      .setTimestamp()
      .setFooter(message.guild.name, message.guild.iconURL());

  logChannel.send({ embeds: [deletedMessageEmbed] });
}




client.on('messageDelete', (message) => {
  if (message.author.bot) return;
  if (message.channel.type === 'DM') return;

  if (!message.guild.me.permissions.has('EMBED_LINKS')) return;
  if (!message.guild.me.permissions.has('MANAGE_MESSAGES')) return;

  if (!log[message.guild.id])
    log[message.guild.id] = {
      onoff: 'Off',
    };

  if (log[message.guild.id].onoff === 'Off') return;

  const logChannel = message.guild.channels.cache.find(
    (c) => c.name === log[message.guild.id].channel
  );

  if (!logChannel) return;

  const messageDelete = new MessageEmbed()
    .setTitle('**[MESSAGE DELETE]**')
    .setColor('RED')
    .setThumbnail(message.author.displayAvatarURL())
    .setDescription(`
      **\n**:wastebasket: Successfully \`DELETE\` **MESSAGE** in ${message.channel}\n\n
      **Channel:** \`\`${message.channel.name}\`\` (ID: ${message.channel.id})\n
      **Message ID:** ${message.id}\n
      **Sent By:** <@${message.author.id}> (ID: ${message.author.id})\n
      **Message:**\n\`\`\`${message.content}\`\`\`
    `)
    .setTimestamp()
    .setFooter(message.guild.name, message.guild.iconURL());

  logChannel.send({ embeds: [messageDelete] });
});

client.on('messageUpdate', (oldMessage, newMessage) => {
  if (oldMessage.author.bot) return;
  if (oldMessage.channel.type === 'DM') return;

  if (!oldMessage.guild.me.permissions.has('EMBED_LINKS')) return;
  if (!oldMessage.guild.me.permissions.has('MANAGE_MESSAGES')) return;

  if (!log[oldMessage.guild.id])
    log[oldMessage.guild.id] = {
      onoff: 'Off',
    };




  if (log[oldMessage.guild.id].onoff === 'Off') return;

  const logChannel = oldMessage.guild.channels.cache.find(
    (c) => c.name === log[oldMessage.guild.id].channel
  );

  if (!logChannel) return;

  if (oldMessage.content.startsWith('https://')) return;

  const messageUpdate = new MessageEmbed()
    .setTitle('**[MESSAGE EDIT]**')
    .setThumbnail(oldMessage.author.displayAvatarURL())
    .setColor('BLUE')
    .setDescription(`
      **\n**:wrench: Successfully \`EDIT\` **MESSAGE** in ${oldMessage.channel}\n\n
      **Channel:** \`\`${oldMessage.channel.name}\`\` (ID: ${oldMessage.channel.id})\n
      **Message ID:** ${oldMessage.id}\n
      **Sent By:** <@${oldMessage.author.id}> (ID: ${oldMessage.author.id})\n\n
      **Old Message:**\`\`\`${oldMessage.content}\`\`\`\n
      **New Message:**\`\`\`${newMessage.content}\`\`\`
    `)
    .setTimestamp()
    .setFooter(oldMessage.guild.name, oldMessage.guild.iconURL());

  logChannel.send({ embeds: [messageUpdate] });
});

client.on('roleCreate', (role) => {
  if (!role.guild.me.permissions.has('EMBED_LINKS')) return;
  if (!role.guild.me.permissions.has('VIEW_AUDIT_LOG')) return;

  if (!log[role.guild.id])
    log[role.guild.id] = {
      onoff: 'Off',
    };

  const logChannel = role.guild.channels.cache.find(
    (c) => c.name === log[role.guild.id].channel
  );

  if (!logChannel) return;

  role.guild.fetchAuditLogs().then((logs) => {
    const auditLog = logs.entries.first();
    if (!auditLog) return;

    const { executor, target } = auditLog;

    if (target.id === role.id) {
      const roleCreate = new MessageEmbed()
        .setTitle('**[ROLE CREATE]**')
        .setColor('GREEN')
        .setThumbnail(executor.displayAvatarURL())
        .setDescription(`
          **\n**:lock_with_ink_pen: Successfully \`CREATE\` **ROLE** in ${role.guild}\n\n
          **Role Name:** \`\`${role.name}\`\` (ID: ${role.id})\n
          **Created By:** <@${executor.id}> (ID: ${executor.id})
        `)
        .setTimestamp()
        .setFooter(role.guild.name, role.guild.iconURL());

      logChannel.send({ embeds: [roleCreate] });
    }
  });
});


client.on('roleDelete', (role) => {
  if (!role.guild.me.permissions.has('EMBED_LINKS')) return;
  if (!role.guild.me.permissions.has('VIEW_AUDIT_LOG')) return;

  if (!log[role.guild.id])
    log[role.guild.id] = {
      onoff: 'Off',
    };

  const logChannel = role.guild.channels.cache.find(
    (c) => c.name === log[role.guild.id].channel
  );

  if (!logChannel) return;

  role.guild.fetchAuditLogs().then((logs) => {
    const auditLog = logs.entries.first();
    if (!auditLog) return;

    const { executor, target } = auditLog;

    if (target.id === role.id) {
      const roleDelete = new MessageEmbed()
        .setTitle('**[ROLE DELETE]**')
        .setColor('RED')
        .setThumbnail(executor.displayAvatarURL())
        .setDescription(`
          **\n**:wastebasket: Successfully \`DELETE\` **ROLE** in ${role.guild}\n\n
          **Role Name:** \`\`${role.name}\`\` (ID: ${role.id})\n
          **Deleted By:** <@${executor.id}> (ID: ${executor.id})
        `)
        .setTimestamp()
        .setFooter(role.guild.name, role.guild.iconURL());

      logChannel.send({ embeds: [roleDelete] });
    }
  });
});
client.on('guildMemberAdd', (member) => {
  if (!member.guild.me.permissions.has('EMBED_LINKS')) return;
  if (!member.guild.me.permissions.has('VIEW_AUDIT_LOG')) return;

  if (!log[member.guild.id])
    log[member.guild.id] = {
      onoff: 'Off',
    };

  const logChannel = member.guild.channels.cache.find(
    (c) => c.name === log[member.guild.id].channel
  );

  if (!logChannel) return;

  member.guild.fetchAuditLogs().then((logs) => {
    const auditLog = logs.entries.first();
    if (!auditLog) return;

    const { executor, target } = auditLog;

    if (target.id === member.id) {
      const memberJoin = new MessageEmbed()
        .setTitle('**[MEMBER JOIN]**')
        .setColor('GREEN')
        .setThumbnail(member.user.displayAvatarURL())
        .setDescription(`
          **\n**:wave: **${member.user.tag}** has joined the server!\n\n
          **Joined By:** ${executor.tag} (ID: ${executor.id})
        `)
        .setTimestamp()
        .setFooter(member.guild.name, member.guild.iconURL());

      logChannel.send({ embeds: [memberJoin] });
    }
  });
});

client.on('guildMemberRemove', (member) => {
  if (!member.guild.me?.permissions.has('EMBED_LINKS')) return;
  if (!member.guild.me?.permissions.has('VIEW_AUDIT_LOG')) return;

  if (!log[member.guild.id])
    log[member.guild.id] = {
      onoff: 'Off',
    };

  const logChannel = member.guild.channels.cache.find(
    (c) => c.name === log[member.guild.id].channel
  );

  if (!logChannel) return;

  member.guild.fetchAuditLogs().then((logs) => {
    const auditLog = logs.entries.first();
    if (!auditLog) return;

    const { executor, target } = auditLog;

    if (target.id === member.id) {
      const memberLeave = new MessageEmbed()
        .setTitle('**[MEMBER LEAVE]**')
        .setColor('RED')
        .setThumbnail(member.user.displayAvatarURL())
        .setDescription(`
          **\n**:wave: **${member.user.tag}** has left the server!\n\n
          **Left By:** ${executor.tag} (ID: ${executor.id})
        `)
        .setTimestamp()
        .setFooter(member.guild.name, member.guild.iconURL());

      logChannel.send({ embeds: [memberLeave] });
    }
  });
});

client.on('channelCreate', (channel) => {
  if (!channel.guild.me?.permissions.has('EMBED_LINKS')) return;
  if (!channel.guild.me?.permissions.has('VIEW_AUDIT_LOG')) return;

  if (!log[channel.guild.id])
    log[channel.guild.id] = {
      onoff: 'Off',
    };

  const logChannel = channel.guild.channels.cache.find(
    (c) => c.name === log[channel.guild.id].channel
  );

  if (!logChannel) return;

  channel.guild.fetchAuditLogs().then((logs) => {
    const auditLog = logs.entries.first();
    if (!auditLog) return;

    const { executor, target } = auditLog;

    if (target.id === channel.id) {
      const channelCreate = new MessageEmbed()
        .setTitle('**[CHANNEL CREATE]**')
        .setColor('GREEN')
        .setThumbnail(executor.displayAvatarURL())
        .setDescription(`
          **\n**:new: Successfully \`CREATE\` **CHANNEL** in ${channel.guild}\n\n
          **Channel Name:** \`\`${channel.name}\`\` (ID: ${channel.id})\n
          **Created By:** <@${executor.id}> (ID: ${executor.id})
        `)
        .setTimestamp()
        .setFooter(channel.guild.name, channel.guild.iconURL());

      logChannel.send({ embeds: [channelCreate] });
    }
  });
});

client.on('channelDelete', (channel) => {
  if (!channel.guild.me?.permissions.has('EMBED_LINKS')) return;
  if (!channel.guild.me?.permissions.has('VIEW_AUDIT_LOG')) return;

  if (!log[channel.guild.id])
    log[channel.guild.id] = {
      onoff: 'Off',
    };

  const logChannel = channel.guild.channels.cache.find(
    (c) => c.name === log[channel.guild.id].channel
  );

  if (!logChannel) return;

  channel.guild.fetchAuditLogs().then((logs) => {
    const auditLog = logs.entries.first();
    if (!auditLog) return;

    const { executor, target } = auditLog;

    if (target.id === channel.id) {
      const channelDelete = new MessageEmbed()
        .setTitle('**[CHANNEL DELETE]**')
        .setColor('RED')
        .setThumbnail(executor.displayAvatarURL())
        .setDescription(`
          **\n**:wastebasket: Successfully \`DELETE\` **CHANNEL** in ${channel.guild}\n\n
          **Channel Name:** \`\`${channel.name}\`\` (ID: ${channel.id})\n
          **Deleted By:** <@${executor.id}> (ID: ${executor.id})
        `)
        .setTimestamp()
        .setFooter(channel.guild.name, channel.guild.iconURL());

      logChannel.send({ embeds: [channelDelete] });
    }
  });
});
//




                                                 ///////////////////////////////////////////////////////////////////
                                                   ///                         اوامر ادارية                 ///
                                                 ///////////////////////////////////////////////////////////////////
const prefixxxxx = `-`
const fal = require ('./models/fal.js')
client.on('messageCreate', (message) => {
  if (message.content.startsWith(prefixxxxx + `setadminrole`)) {
    // Check if the user has permission to manage server roles
    if (!message.member.permissions.has('MANAGE_ROLES')) {
      message.reply('You do not have permission to set the admin role.');
      return;
    }
    // Get the role name from the command argument

    
    const roleName = message.mentions.roles.first()
    // Find the role object by name
  if (!roleName) return message.reply({content : `please mention a role`})
    // If the role is found, update the server's configuration file
  fal.findOneAndUpdate(
{ id: message.guild.id },
{ role: roleName.id },
{ upsert: true },
(err, doc) => {
if (err) {
console.error(err);
message.reply('An error occurred while saving the admin role name.');
} else {
message.reply('Admin role name saved successfully.');
}
}
);
  }
});




client.on('messageCreate',async (message) => {
  if (message.content.startsWith(prefixxxxx + `unban`)) {
    // Check if the user has the admin role
    
       const role = await fal.findOne({ id: message.guild.id });
const adminRole = message.guild.roles.cache.get(role.role);
if (!adminRole) {
message.reply('The admin role has not been set for this server.');
return;
}
if (!message.member.roles.cache.has(adminRole.id)) {
message.reply('You do not have permission to unban users.');
return;
}
    
    // Proceed with the unban command as before
    const user = message.mentions.users.first();
    if (!user) {
      message.reply('Please mention a valid user ID');
      return;
    }
    message.guild.bans.fetch(user)
      .then(ban => {
        const member = ban.user;
        message.guild.members.unban(user.id)
          .then(() => message.reply(`${user.tag} was unbanned from the server.`))
          .catch(error => message.reply('Sorry, an error occurred.'));
      })
      .catch(error => message.reply('Sorry, an error occurred.'));
    
  }
});

///
client.on('messageCreate', async (message) => {
  if (message.content.startsWith(prefixxxxx + `ban`)) {
    // Check if the user has the admin role
   const role = await fal.findOne({ id: message.guild.id });
const adminRole = message.guild.roles.cache.get(role.role);
if (!adminRole) {
message.reply('The admin role has not been set for this server.');
return;
}
if (!message.member.roles.cache.has(adminRole.id)) {
message.reply('You do not have permission to ban users.');
return;
}

    // Proceed with the ban command as before
    const member = message.mentions.members.first();
    if (!member) {
      message.reply('Please mention a valid member of this server');
      return;
    }
    member.ban()
      .then(() => message.reply(`${member.user.tag} was banned from the server.`))
      .catch(error => message.reply('Sorry, an error occurred.'));
    }
  
});
//

client.on('messageCreate', async (message) => {
if (message.content.startsWith(prefixxxxx + `warn`)) {
const role = await fal.findOne({ id: message.guild.id });
const adminRole = message.guild.roles.cache.get(role.role);
if (!adminRole) {
message.reply('The admin role has not been set for this server.');
return;
}
if (!message.member.roles.cache.has(adminRole.id)) {
message.reply('You do not have permission to warn users.');
return;
}

// Get the warned member and reason from the command arguments
const args = message.content.slice(6).trim().split(/ +/);
const member = message.mentions.members.first();
const reason = args.slice(1).join(' ');
// Warn the member
if (member) {
const warnEmbed = new Discord.MessageEmbed()
.setTitle(`Warning for ${member.user.tag}`)
.setColor('#ff0000')
.setDescription(`Reason: ${reason}`)
.setTimestamp();
message.channel.send({ embeds: [warnEmbed] });
await member.send({embeds : [warnEmbed]})
}
}

})

///
client.on('messageCreate',async  (message) => {
if (message.content.startsWith(prefixxxxx + `kick`)) {
const role = await fal.findOne({ id: message.guild.id });
const adminRole = message.guild.roles.cache.get(role.role);
if (!adminRole) {
message.reply('The admin role has not been set for this server.');
return;
}
if (!message.member.roles.cache.has(adminRole.id)) {
message.reply('You do not have permission to kick users.');
return;
}

// Get the kicked member and reason from the command arguments
const args = message.content.slice(6).trim().split(/ +/);
const member = message.mentions.members.first();
const reason = args.slice(1).join(' ');
// Kick the member
if (member) {
member.kick(reason)
  .then(() => {
    const kickEmbed = new Discord.MessageEmbed()
      .setTitle(`User ${member.user.tag} has been kicked`)
      .setColor('#ff0000')
      .setDescription(`Reason: ${reason}`)
      .setTimestamp();
    message.channel.send({ embeds: [kickEmbed] });
  })
}
}

})
//


  ///

  client.on('messageCreate',async  (message) => {
    if (message.content.startsWith(prefixxxxx + `mute`)) {
      // Check if the user has the admin role
const role = await fal.findOne({ id: message.guild.id });
const adminRole = message.guild.roles.cache.get(role.role);
if (!adminRole) {
message.reply('The admin role has not been set for this server.');
return;
}
if (!message.member.roles.cache.has(adminRole.id)) {
message.reply('You do not have permission to mute users.');
return;
}
      
      // Get the muted member and reason from the command arguments
      const args = message.content.slice(6).trim().split(/ +/);
      const member = message.mentions.members.first();
      const reason = args.slice(1).join(' ');
      // Mute the member
      if (member) {
        const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');
        if (!muteRole) {
          message.reply('The Muted role does not exist. Please create it before using this command.');
          return;
        }
        member.roles.add(muteRole, reason)
          .then(() => {
            const muteEmbed = new Discord.MessageEmbed()
              .setTitle(`User ${member.user.tag} has been muted`)
              .setColor('#ff0000')
              .setDescription(`Reason: ${reason}`)
              .setTimestamp();
            message.channel.send({ embeds: [muteEmbed] });
          })
        }
      }
      
    })

    client.on('messageCreate',async  (message) => {
      if (message.content.startsWith(prefixxxxx + `unmute`)) {
        // Check if the user has the admin role
    const role = await fal.findOne({ id: message.guild.id });
const adminRole = message.guild.roles.cache.get(role.role);
if (!adminRole) {
message.reply('The admin role has not been set for this server.');
return;
}
if (!message.member.roles.cache.has(adminRole.id)) {
message.reply('You do not have permission to unmute users.');
return;
}
        
        // Get the unmuted member from the command arguments
        const member = message.mentions.members.first();
        if (member) {
          const muteRole = message.guild.roles.cache.find(role => role.name === 'Muted');
          if (!muteRole) {
            message.reply('The Muted role does not exist. Please create it before using this command.');
            return;
          }
          member.roles.remove(muteRole)
            .then(() => {
              const unmuteEmbed = new Discord.MessageEmbed()
                .setTitle(`User ${member.user.tag} has been unmuted`)
                .setColor('#00ff00')
                .setTimestamp();
              message.channel.send({ embeds: [unmuteEmbed] });
            })
          }
        }
        
      })



                                                   ///////////////////////////////////////////////////////////////////
                                                   ///                       اوتو ريبلاى                             ///
                                                   ///////////////////////////////////////////////////////////////////





      client.on('interactionCreate', async interaction => {
        if (!interaction.isCommand()) return
        if (interaction.commandName === 'autoreply') {
          const auto = require ('./models/autoreply.js')
           
               if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return interaction.reply({
              content: 'You do not have permission to use this command!',
              ephemeral: true,
            });
          }
      
          const word = interaction.options.getString('word')
      
          const reply = interaction.options.getString('reply')
      
       
       await auto.findOneAndUpdate(
            {id : interaction.guild.id} ,
            {
              word : word , reply : reply
            } ,
            {upsert : true}
          ) 
          const gac = await auto.findOne({id : interaction.guild.id})
      await interaction.reply({content : `Done saved word  And its reply ` , ephemeral : true})
         
        }
        })
      //
      client.on('interactionCreate', async interaction => {
        if (!interaction.isCommand()) return;
      
        if (interaction.commandName === 'delete-word') {
          const auto = require('./models/autoreply.js');
      
          if (!interaction.member.permissions.has(Permissions.FLAGS.MANAGE_GUILD)) {
            return interaction.reply({
              content: 'You do not have permission to use this command!',
              ephemeral: true,
            });
          }
      
          const word = interaction.options.getString('word');
      
          let data = await auto.findOne({ id: interaction.guild.id });
          if (!data) {
            return interaction.reply({ content: 'No data found.', ephemeral: true });
          }
      
          if (!data.word) {
            return interaction.reply({ content: 'The specified word was not found.', ephemeral: true });
          }
      
        
      
          await interaction.reply({ content: `The word "${word}" has been deleted.`, ephemeral: true });
        }
      });
      ///
      
      client.on('messageCreate', async message => {
      
          const auto = require ('./models/autoreply.js')
          const gac = await auto.findOne({id : message.guild.id})
        if(message.content === `${gac.word}`) {
          await message.channel.send({content : `${gac.reply}`})
        }
      })
      



                                                 ///////////////////////////////////////////////////////////////////
                                                 ///                       اوتو رول                             ///
                                                 ///////////////////////////////////////////////////////////////////

client.on('guildMemberAdd', async member => {
 
  const roleId = '123456789012345678'; // Replace this with the actual role ID

  
  const role = member.guild.roles.cache.get(roleId);

  if (role) {
      try {
          await member.roles.add(role);
          console.log(`Assigned role '${role.name}' to ${member.user.tag}`);
      } catch (error) {
          console.error(`Error assigning role '${role.name}' to ${member.user.tag}:`, error);
      }
  }
});

client.on('guildCreate', async guild => {
  //
  const botRoleId = '123456789012345678'; // Replace this with the actual role ID

 
  const botRole = guild.roles.cache.get(botRoleId);

  if (botRole) {
     
      const botMember = guild.members.cache.get(client.user.id);

      if (botMember) {
          try {
              await botMember.roles.add(botRole);
            
          } catch (error) {
              console.error(`Error assigning role '${botRole.name}' to the bot in ${guild.name}:`, error);
          }
      }
  }
});















// let optionssr = [{
//   label: 'General',
//   description: "Commads for system bot",
//   value: 'n1',
//   emoji: `1164786595556237322`,

//   selected: false
// },
// {
//   label: 'Moderation',
//   description: "Ticket setup",
//   value: 'n2',
//   emoji: `1165184280629084170`,

//   selected: false
// },

// {
//   label: 'Azkar',
//   description: "Moderation Commands",
//   value: 'n3',
//   emoji: `1165159370808627260`,

//   selected: false
// },
// {
//   label: 'Welcome',
//   description: "Logs Commands",
//   value: 'n4',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Ticket',
//   description: "Logs Commands",
//   value: 'n5',
//   emoji: `1165159747717169172`,

//   selected: false
// },

// {
//   label: 'Autorole',
//   description: "Logs Commands",
//   value: 'n6',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Come',
//   description: "Logs Commands",
//   value: 'n7',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Embed',
//   description: "Logs Commands",
//   value: 'n8',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Say',
//   description: "Logs Commands",
//   value: 'n9',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Feedback',
//   description: "Logs Commands",
//   value: 'n10',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Log',
//   description: "Logs Commands",
//   value: 'n11',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Suggestion',
//   description: "Logs Commands",
//   value: 'n12',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Autoreaction',
//   description: "Logs Commands",
//   value: 'n13',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// {
//   label: 'Autoline',
//   description: "Logs Commands",
//   value: 'n14',
//   emoji: `1165159747717169172`,

//   selected: false
// },
// ];

// Shorten the value of each option to 100 characters or less
// optionssr.forEach(option => {
// option.value = option.value.slice(0, 100);
// });





                                            ///////////////////////////////////////////////////////////////////
                                            ///                     امر الهيلب                            ///
                                            ///////////////////////////////////////////////////////////////////







client.on('messageCreate', async message => {
  if (message.content.startsWith(prefixxxxx + 'help')) {



   const buttonsRow = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('arabic')
          .setLabel('Arabic')
          .setEmoji('💥')
          .setStyle('SECONDARY'),
        new MessageButton()
          .setCustomId('english')
          .setLabel('English')
          .setEmoji('🔰')
          .setStyle('PRIMARY')
      );



await message.reply({embeds : [new MessageEmbed().setDescription(`Thank you for using the bot`).setTitle(`Select Language`)] , components :[buttonsRow]})





    
    
   
  }
})




client.on('interactionCreate' , async interaction =>{
  if(!interaction.isButton())return
  if (interaction.customId === `english`) {


    
    

await interaction.update({embeds: [ new MessageEmbed()
  .setTitle(`Help panel`)
   .setDescription(`**Bot system for anything you want**`)
   .addFields({
     name: `Command Categories`,
     value: `**General\nModeration\nAzkar\nWelcome\nTicket\nAutorole\nCome\nEmbed\nSay\nFeedback\nnLog\nSuggestion\nAutoreaction\nAutoline**`
   })
   .setImage('https://media.discordapp.net/attachments/1146894977486561341/1165175086458880070/IMG_20231021_092900.png?ex=6545e4dc&is=65336fdc&hm=3b8ec0bb15c939f6379fb95d54fa535dbecdd86edf59864a1d527f0241cb8f08&=').setThumbnail(interaction.guild.iconURL({
     dynamic: true
   }))
     .setColor('RANDOM')] })

     const member = interaction.member
     member.send({embeds : [ new MessageEmbed()
      .setTitle(`Help panel`)
       .setDescription(`**Bot system for anything you want**`)
       .addFields({
         name: `Command Categories`,
         value: `**General\nModeration\nAzkar\nWelcome\nTicket\nAutorole\nCome\nEmbed\nSay\nFeedback\nnLog\nSuggestion\nAutoreaction\nAutoline**`
       })
       .setImage('https://media.discordapp.net/attachments/1146894977486561341/1165175086458880070/IMG_20231021_092900.png?ex=6545e4dc&is=65336fdc&hm=3b8ec0bb15c939f6379fb95d54fa535dbecdd86edf59864a1d527f0241cb8f08&=').setThumbnail(interaction.guild.iconURL({
         dynamic: true
       }))
         .setColor('RANDOM')]})
  }
})




client.on('interactionCreate' , async interaction =>{
  if(!interaction.isButton())return
  if (interaction.customId === `arabic`) {

    

await interaction.update({embeds: [ new MessageEmbed()
  .setTitle(`ايمة الهيلب`)
   .setDescription(`**بوت سيستيم **`)
   .addFields({
     name: `كاتوجرى الاوامر`,
     value: `**عام\nاوامر ادارية\nأذكار\nترحيب\nتكت\nاوتو رول\nنداء\nامبيد\nساى\nاراء\nلوق\nاقتراحات\nاوتو رياكشن\nاوتو لاين**`
   })
   .setImage('https://media.discordapp.net/attachments/1146894977486561341/1165175086458880070/IMG_20231021_092900.png?ex=6545e4dc&is=65336fdc&hm=3b8ec0bb15c939f6379fb95d54fa535dbecdd86edf59864a1d527f0241cb8f08&=').setThumbnail(interaction.guild.iconURL({
     dynamic: true
   }))
     .setColor('RANDOM')] })
     const member = interaction.member
     member.send({embeds : [ new MessageEmbed()
      .setTitle(`ايمة الهيلب`)
       .setDescription(`**بوت سيستيم **`)
       .addFields({
         name: `كاتوجرى الاوامر`,
         value: `**عام\nاوامر ادارية\nأذكار\nترحيب\nتكت\nاوتو رول\nنداء\nامبيد\nساى\nاراء\nلوق\nاقتراحات\nاوتو رياكشن\nاوتو لاين**`
       })
       .setImage('https://media.discordapp.net/attachments/1146894977486561341/1165175086458880070/IMG_20231021_092900.png?ex=6545e4dc&is=65336fdc&hm=3b8ec0bb15c939f6379fb95d54fa535dbecdd86edf59864a1d527f0241cb8f08&=').setThumbnail(interaction.guild.iconURL({
         dynamic: true
       }))
         .setColor('RANDOM')]})

  }
})























/// https://youtu.be/gtykpkOYy94

client.login("MTIyNzIyNjM0MTk1MTQxMDE4Ng.G-Oreo.VT0DwhD8t8r3BZoXM0S13_14uDcymcsRh3yNzw");